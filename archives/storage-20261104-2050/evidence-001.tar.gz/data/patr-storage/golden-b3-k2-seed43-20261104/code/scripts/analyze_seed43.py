import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def read(root):
 g={}
 for i in range(1,6):
  for s in (root/f'batch{i}.jsonl').read_text().splitlines():
   r=json.loads(s);g.setdefault(r['task']['uid'],[]).append(float(r['reward']>0))
 assert len(g)==500 and all(len(v)==4 for v in g.values())
 return {u:np.mean(v) for u,v in g.items()}
a=read(ROOT/'runs/supplemental500');b=read(Path('/home/vipuser/golden-next-20261031/b3/code/runs/supplemental500/tree_random'));assert a.keys()==b.keys()
excluded=set(json.loads(Path('/home/vipuser/golden-controls-20261031/code/runs/audit/overlap_report.json').read_text())['excluded_uids'])
r=dict(purpose='Report seed43 repeat of B3 Random K=2; two seeds do not estimate training-seed uncertainty reliably',primary_ucf_comparator='CERT-Uniform',random_role='separate performance benchmark',splits={})
for split,us in [('all500',sorted(a)),('filtered409',sorted(set(a)-excluded))]:
 assert len(us)==(500 if split=='all500' else 409)
 av=np.array([a[u] for u in us]);bv=np.array([b[u] for u in us]);delta=av-bv;rng=np.random.default_rng(20261104);boot=[]
 for _ in range(100):boot.extend(delta[rng.integers(len(us),size=(100,len(us)))].mean(1)*100)
 r['splits'][split]=dict(n_tasks=len(us),seed42_pct=float(bv.mean()*100),seed43_pct=float(av.mean()*100),difference_pp=float(delta.mean()*100),task_paired_ci95_pp=np.quantile(boot,[.025,.975]).tolist(),replicates=10000)
(ROOT/'runs/seed43_stability_report.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
