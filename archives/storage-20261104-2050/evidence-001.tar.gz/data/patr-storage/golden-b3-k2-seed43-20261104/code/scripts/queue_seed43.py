"""Wait for completed UCF main arm, then use the common exclusive GPU lease."""
import fcntl,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'runs/queue';Q.mkdir(parents=True,exist_ok=True)
UCF=Path('/data/patr-storage/golden-ucf-20261103/code');PY='/home/vipuser/patr-reproduction/.venv/bin/python'
def save(status,**kw):
 p=Q/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(dict(status=status,pid=os.getpid(),updated=time.time(),**kw),indent=2));tmp.replace(p)
def gpu():return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
def main():
 with (Q/'scheduler.lock').open('a+') as single:
  fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
  plan=json.loads((ROOT/'artifacts/seed43_plan.json').read_text());prereq=Path(plan['prerequisite'])
  while True:
   s=json.loads(prereq.read_text()) if prereq.exists() else {}
   if s.get('status')=='complete' and s.get('step')==400:break
   gate=UCF/'artifacts/phase1_gate.json'
   if gate.exists() and not json.loads(gate.read_text())['passed']:save('not_eligible_ucf_main_not_started_phase1_failed');return
   save('waiting_ucf_main_complete',prerequisite=str(prereq),observed=s.get('status','not_started'));time.sleep(30)
  with open('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock','a+') as lease:
   while True:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:save('waiting_idle_gpu_lock');time.sleep(20);continue
    if not gpu():break
    fcntl.flock(lease,fcntl.LOCK_UN);save('waiting_idle_gpu_process');time.sleep(20)
   def run(stage,args):
    assert not gpu();assert shutil.disk_usage(ROOT).free>=16*1024**3
    for f,h in plan['source_sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
    env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
    with (Q/(stage+'.log')).open('a') as log:
     p=subprocess.Popen([PY,'-u',*args],cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
     save('running',stage=stage,child_pid=p.pid);assert p.wait()==0,stage
    for _ in range(60):
     if not gpu():break
     time.sleep(2)
   args=['run_b3.py','--config','configs/b3_k2_seed43.json','--method','tree_random']
   smoke=ROOT/'runs/smoke/tree_random_seed43/status.json'
   if not smoke.exists() or json.loads(smoke.read_text()).get('status')!='smoke_complete':run('smoke',args+['--smoke'])
   formal=ROOT/'runs/formal/tree_random_seed43';status=formal/'status.json'
   if not status.exists() or json.loads(status.read_text()).get('status')!='complete':run('formal',args+(['--resume'] if (formal/'checkpoint.pt').exists() else []))
   supp=ROOT/'runs/supplemental500';complete=supp/'status.json'
   if not complete.exists() or json.loads(complete.read_text()).get('status')!='complete':
    if supp.exists():supp.rename(supp.with_name('supplemental500_incomplete_'+str(time.time_ns())))
    run('supplemental500',['scripts/golden_supplemental.py','--model',str(formal/'final_model'),'--output',str(supp)])
   subprocess.run([PY,'scripts/analyze_seed43.py'],cwd=ROOT,check=True)
  save('complete_seed43_stability_report')
if __name__=='__main__':
 try:main()
 except BlockingIOError:raise SystemExit('Existing seed43 queue owns lock')
 except Exception as e:save('error_evidence_retained',error=repr(e));raise
