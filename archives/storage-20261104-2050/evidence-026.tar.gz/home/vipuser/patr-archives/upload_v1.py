import os,json,subprocess,hashlib,time,traceback,urllib.request
from pathlib import Path
root=Path('/home/vipuser/patr-archives'); parts=root/'release-parts-20261014'
gh=str(root/'github-tools/gh');repo='EthanY666999/decision-point';tag='patr-v1-full-archive-20261014'
status=root/'github_v1_upload_status.json'
def write(state,**kw):
 status.write_text(json.dumps({'state':state,'updated':time.time(),**kw},indent=2))
def run(args):return subprocess.check_output([gh]+args,text=True,stderr=subprocess.PIPE)
try:
 manifest=json.loads((parts/'ARCHIVE.json').read_text())
 try:run(['release','view',tag,'--repo',repo,'--json','id'])
 except subprocess.CalledProcessError:
  run(['release','create',tag,'--repo',repo,'--title','PaTR V1 full archive — 2026-10-14','--notes','Full first-stage archive, including model/checkpoints, trajectories, code and environment. Upload/verification in progress; do not delete originals until a VERIFIED manifest is present. See ARCHIVE.json and RESTORE.txt.'])
 completed=[]
 for part in manifest['parts']+[{'file':x} for x in ['ARCHIVE.json','SHA256SUMS','RESTORE.txt']]:
  name=part['file'];path=parts/name
  write('uploading',file=name,completed=completed)
  h=hashlib.sha256()
  with path.open('rb') as f:
   while b:=f.read(8*1024*1024):h.update(b)
  sha=h.hexdigest()
  if 'sha256' in part:assert sha==part['sha256'], 'Local checksum mismatch '+name
  assets=json.loads(run(['api',f'repos/{repo}/releases/tags/{tag}']))['assets']
  asset=next((a for a in assets if a['name']==name),None)
  if asset is None:
   run(['release','upload',tag,str(path),'--repo',repo])
   assets=json.loads(run(['api',f'repos/{repo}/releases/tags/{tag}']))['assets']
   asset=next(a for a in assets if a['name']==name)
  assert asset['size']==path.stat().st_size,'Remote size mismatch '+name
  assert asset.get('digest')=='sha256:'+sha,'Remote digest mismatch '+name
  write('download_verifying',file=name,completed=completed)
  h=hashlib.sha256();n=0
  with urllib.request.urlopen(asset['browser_download_url'],timeout=120) as f:
   while b:=f.read(8*1024*1024):h.update(b);n+=len(b)
  assert h.hexdigest()==sha and n==path.stat().st_size,'Download mismatch '+name
  completed.append({'file':name,'bytes':n,'sha256':sha,'asset_url':asset['browser_download_url'],'download_verified':True})
  print('VERIFIED',name,n,flush=True)
 receipt={'state':'all_assets_download_verified','tag':tag,'repo':repo,'files':completed,'archive_sha256':manifest['sha256']}
 (parts/'VERIFIED.json').write_text(json.dumps(receipt,indent=2))
 run(['release','upload',tag,str(parts/'VERIFIED.json'),'--repo',repo])
 write('complete_verified',**receipt)
except Exception as e:
 write('failed',error=str(e));traceback.print_exc();raise
