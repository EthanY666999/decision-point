from pathlib import Path
import hashlib,json,time
root=Path('/home/vipuser/patr-archives')
a=root/'patr-user-stop-20261014.tar.gz'
out=root/'release-parts-20261014'
out.mkdir(exist_ok=True)
size=1900000000
parts=[]
whole=hashlib.sha256()
with a.open('rb') as f:
    i=0
    while f.tell()<a.stat().st_size:
        name=a.name+'.part%03d'%i
        p=out/name
        h=hashlib.sha256();n=0
        with p.open('wb') as g:
            while n<size:
                b=f.read(min(8*1024*1024,size-n))
                if not b:break
                g.write(b);h.update(b);whole.update(b);n+=len(b)
        parts.append(dict(file=name,bytes=n,sha256=h.hexdigest()))
        print(name,n,flush=True);i+=1
expected=(root/(a.name+'.sha256')).read_text().split()[0]
assert whole.hexdigest()==expected,'Source archive checksum mismatch'
(out/'SHA256SUMS').write_text(''.join(p['sha256']+'  '+p['file']+'\n' for p in parts))
(out/'ARCHIVE.json').write_text(json.dumps(dict(original=a.name,bytes=a.stat().st_size,sha256=expected,parts=parts),indent=2)+'\n')
(out/'RESTORE.txt').write_text('Download all .part files and SHA256SUMS into one directory.\nRun: sha256sum -c SHA256SUMS\nRun: cat patr-user-stop-20261014.tar.gz.part* > patr-user-stop-20261014.tar.gz\nVerify the combined SHA-256 against ARCHIVE.json, then run gzip -t and extract with tar -xzf.\nThis archive includes checkpoints, models, trajectories, source and .venv.\n')
(root/'release_parts_status.txt').write_text('complete_verified '+time.strftime('%Y-%m-%d %H:%M:%S')+'\n')
print('complete_verified',len(parts),flush=True)
