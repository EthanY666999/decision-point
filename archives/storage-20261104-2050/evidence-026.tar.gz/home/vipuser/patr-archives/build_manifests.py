from pathlib import Path
import hashlib,json,os,tarfile,time
out=Path('/home/vipuser/patr-archives/inventory-20261015');out.mkdir(exist_ok=True)
def sha(f):
 h=hashlib.sha256()
 while b:=f.read(8*1024*1024):h.update(b)
 return h.hexdigest()
for name in ['patr-reproduction','patr-reproduction-v2']:
 root=Path('/home/vipuser')/name;rows=[]
 for base,dirs,files in os.walk(root,followlinks=False):
  for n in sorted(dirs+files):
   p=Path(base)/n
   if p.is_symlink():rows.append({'path':str(p.relative_to(root)),'symlink':os.readlink(p)});continue
   if not p.is_file():continue
   before=p.stat()
   with p.open('rb') as f:h=sha(f)
   after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),str(p)+' changed'
   rows.append({'path':str(p.relative_to(root)),'bytes':after.st_size,'sha256':h})
 (out/(name+'-manifest.json')).write_text(json.dumps({'root':str(root),'created':time.time(),'files':rows},indent=2))
 print(name,len(rows),'hashed',flush=True)
rows=[]
with tarfile.open('/home/vipuser/patr-archives/patr-user-stop-20261014.tar.gz','r|gz') as tar:
 for m in tar:
  if m.isfile():
   f=tar.extractfile(m);rows.append({'path':m.name,'bytes':m.size,'sha256':sha(f)})
  elif m.issym() or m.islnk():rows.append({'path':m.name,'link':m.linkname,'type':'symlink' if m.issym() else 'hardlink'})
(out/'v1-archive-members.json').write_text(json.dumps({'files':rows},indent=2))
print('archive',len(rows),'hashed',flush=True)
