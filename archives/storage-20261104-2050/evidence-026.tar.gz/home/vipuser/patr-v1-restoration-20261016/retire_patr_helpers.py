import hashlib,json,os,tarfile
from pathlib import Path
remote=Path('/home/vipuser/patr-v1-restoration-20261016').is_dir()
if remote:
    base=Path('/home/vipuser');r=base/'patr-v1-restoration-20261016'
    paths=[base/(n+'.py') for n in ('launch_overnight','setup_overnight','setup_patr_alerts','setup_patr_eager')]
    paths+=list(base.glob('patr-cuda-*.py'))
else:
    base=Path('/Users/ethan/Documents/ChatGPT/ACL2027');r=base/'output/patr-v1-restoration-20261016/local'
    paths=[base/'output'/name for name in (
        'patr-v42-execution-20261015/run_pipeline.py','patr-v42-execution-20261015/deep-audit/gradient_diagnostic.py',
        'patr-v43-execution-20261015/run_pipeline.py','patr-v43-execution-20261015/resume_storage_once.py',
        'patr-v43-cuda-diagnostic-20261016/minimal_graph_probe.py','patr-v43-cuda-diagnostic-20261016/minimal_probe.py',
        'patr-v43-cuda-diagnostic-20261016/replay.py','patr-v43-cuda-diagnostic-20261016/replay_async.py')]
paths=sorted(p for p in paths if p.is_file())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=[{'path':str(p.relative_to(base)),'sha256':sha(p),'size':p.stat().st_size} for p in paths]
archive=r/'retired-external-launchers.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for p,e in zip(paths,entries):tf.add(p,arcname=e['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    for e in entries:assert hashlib.sha256(tf.extractfile(e['path']).read()).hexdigest()==e['sha256']
for p,e in zip(paths,entries):
    assert sha(p)==e['sha256'];p.unlink()
result={'archive':str(archive),'sha256':sha(archive),'files_removed':entries,'verified_before_deletion':True}
(r/'EXTERNAL_LAUNCHERS_REMOVED.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'removed':len(paths),'archive_sha256':result['sha256']}))
