import hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/home/vipuser/patr-v1-restoration-20261016');v1=Path('/home/vipuser/patr-reproduction')
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
m=json.loads((r/'REMOVAL_MANIFEST.json').read_text())
assert all(not (Path(m['base'])/e['path']).exists() for e in m['files'])
identity=hashlib.sha256((v1/'train.py').read_bytes()+(v1/'patr_core.py').read_bytes()).hexdigest()
assert identity==m['v1_source_identity']
assert digest(v1/'artifacts/data.json')=='5f15b04e47338132d9de8ba732ccc66c97c7142cc6200161cfd03e0eb18bfdf9'
for p in (v1/'train.py',v1/'patr_core.py'):compile(p.read_bytes(),str(p),'exec')
processes=subprocess.check_output(['ps','-eo','pid,args'],text=True)
active=[s for s in processes.splitlines() if any(x in s for x in ('python -u train','python train','python3 train','overnight_controller.py','scripts/run_queue.py','reports/run_pipeline.py')) and 'verify_patr_v1_restore' not in s]
assert not active,active
cp=Path('/home/vipuser/patr-reproduction-v43-xformers/runs/patr-400-xformers-a/user-stopped-checkpoint.pt')
cp_sha=digest(cp)
assert cp_sha=='ef600f01d3de19d1a47ab7ea46f65d5321cebf8935bcfbd6d5b38d9f09797952'
assert '17 passed, 1 deselected' in (r/'cpu_validation.log').read_text()
result={'state':'v1_restored_verified_training_stopped','source_identity':identity,
    'source_hashes':{n:digest(v1/n) for n in ('train.py','patr_core.py','configs/frozenlake_05b.json','artifacts/data.json')},
    'cpu_tests':{'passed':17,'deselected':1,'excluded_test':'test_first_update_is_checkpointed_before_second_rollout_failure','reason':'Post-V1 Tree-Random behavior is absent from the actual PaTR400 source snapshot'},
    'removed_newer_active_paths':len(m['files']),'newer_active_paths_absent':True,
    'stopped_run_checkpoint':{'path':str(cp),'sha256':cp_sha,'unchanged':True,'step':364},
    'active_training_processes':active,'training_started':False,'finished_unix':time.time()}
(r/'FINAL_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
