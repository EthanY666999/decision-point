import os, sys, json, stat, time, hashlib, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCOPE = json.loads((ROOT / 'cleanup_scope.json').read_text())
TARGETS = [Path(x) for x in SCOPE['candidates']]
PROTECTED = [Path(x) for x in SCOPE['protected_roots']]

def under(p, root):
    return p == root or root in p.parents

def emit(event, **fields):
    record = dict(time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), event=event, **fields)
    with (ROOT / 'events.jsonl').open('a') as f:
        f.write(json.dumps(record, ensure_ascii=False) + '\n')
        f.flush(); os.fsync(f.fileno())
    print(json.dumps(record, ensure_ascii=False), flush=True)

def dump(name, data):
    p = ROOT / name
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    os.replace(tmp, p)

def walk(root):
    yield root
    if root.is_dir() and not root.is_symlink():
        for parent, dirs, files in os.walk(root, followlinks=False):
            for name in dirs + files:
                yield Path(parent) / name

def snapshot(roots):
    records = {}
    for root in roots:
        for p in walk(root):
            s = p.lstat()
            records[str(p)] = [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns,
                               os.readlink(p) if p.is_symlink() else None]
    return records

def assert_safe():
    for p in TARGETS:
        assert p.parent in (Path('/home/vipuser'), Path('/data/patr-storage')), p
        for q in PROTECTED:
            assert not under(p, q) and not under(q, p), (p, q)
        assert not p.is_symlink(), ('target root is symlink', p)
    for root in PROTECTED:
        assert root.exists(), ('missing protected root', root)
        for p in walk(root):
            if p.is_symlink():
                real = p.resolve()
                assert not any(under(real, x) for x in TARGETS), ('protected symlink dependency', p, real)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            cwd = (proc / 'cwd').resolve(strict=True)
            cmd = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        except (PermissionError, FileNotFoundError, ProcessLookupError):
            continue
        assert not any(under(cwd, x) or str(x) in cmd for x in TARGETS), ('active process', proc.name, cmd)

def disk():
    return {p: dict(zip(('total', 'used', 'free'), shutil.disk_usage(p))) for p in ['/', '/data']}

def prepare():
    assert_safe()
    existing = []
    seen = set()
    for p in TARGETS:
        assert p.exists(), ('candidate absent', p)
        s = p.lstat(); allocated = 0; files = 0; logical = 0
        for q in walk(p):
            t = q.lstat()
            assert t.st_dev == s.st_dev, ('nested filesystem', q)
            inode = (t.st_dev, t.st_ino)
            if inode not in seen:
                allocated += t.st_blocks * 512
                seen.add(inode)
            if stat.S_ISREG(t.st_mode):
                files += 1; logical += t.st_size
        existing.append(dict(path=str(p), dev=s.st_dev, inode=s.st_ino,
                             allocated_bytes=allocated, logical_bytes=logical, regular_files=files))
    before = snapshot(PROTECTED)
    dump('protected_before.json', before)
    dump('plan.json', dict(authorization=SCOPE['authorization'], candidates=existing,
                           protected_roots=[str(x) for x in PROTECTED], protected_entries=len(before),
                           disk_before=disk()))
    emit('prepared', candidates=len(existing), allocated_GiB=round(sum(x['allocated_bytes'] for x in existing)/2**30, 3),
         protected_entries=len(before), protected_dependency_conflicts=0)

def verify():
    before = json.loads((ROOT / 'protected_before.json').read_text())
    after = snapshot(PROTECTED)
    missing = sorted(set(before)-set(after))
    changed = [p for p in before if p in after and before[p] != after[p]]
    assert not missing and not changed, ('protected changes', missing[:10], changed[:10])
    emit('protected_metadata_verified', entries=len(before), missing=0, changed=0)
    entries = json.loads((ROOT / 'success_manifest.json').read_text())['entries']
    failures = []; count = 0; total = 0; last = time.monotonic()
    for e in entries:
        if not e.get('sha256'):
            continue
        p = Path(e['path']); h = hashlib.sha256()
        try:
            with p.open('rb') as f:
                for chunk in iter(lambda: f.read(8*1024*1024), b''):
                    h.update(chunk)
            ok = h.hexdigest() == e['sha256'] and p.stat().st_size == e['size']
        except OSError:
            ok = False
        if not ok:
            failures.append(str(p))
        count += 1; total += e['size']
        if time.monotonic()-last > 20:
            emit('success_hash_progress', files=count, GiB=round(total/2**30, 2), failures=len(failures))
            last = time.monotonic()
    residual=[]
    for p in TARGETS:
        if p.exists():
            for q in walk(p):
                s=q.lstat()
                if stat.S_ISREG(s.st_mode):
                    residual.append(dict(path=str(q),size=s.st_size,uid=s.st_uid))
    residual_is_only_root_cache=all('RETIRED_ROOT_OWNED_PYCACHE_20261016' in Path(e['path']).parts and e['uid']==0 and e['path'].endswith('.pyc') for e in residual)
    result = dict(passed=not failures and residual_is_only_root_cache, protected_entries_unchanged=len(before),
                  hashed_success_files=count, hashed_success_bytes=total, hash_failures=failures,
                  removed_all=all(not p.exists() and not p.is_symlink() for p in TARGETS), root_owned_cache_residual=residual, disk_after=disk())
    plan=json.loads((ROOT / 'plan.json').read_text())
    result['freed_bytes_by_disk']={p:result['disk_after'][p]['free']-plan['disk_before'][p]['free'] for p in result['disk_after']}
    dump('result.json', result)
    emit('verification_complete', **result)
    assert result['passed']

def apply():
    assert_safe()
    plan=json.loads((ROOT / 'plan.json').read_text())
    assert [x['path'] for x in plan['candidates']] == [str(x) for x in TARGETS]
    assert snapshot(PROTECTED) == json.loads((ROOT / 'protected_before.json').read_text())
    completed = {e['path'] for e in (json.loads(line) for line in (ROOT/'events.jsonl').read_text().splitlines()) if e['event']=='deleted'}
    for e in plan['candidates']:
        p=Path(e['path'])
        if not p.exists():
            assert str(p) in completed, ('unexpected missing target', p)
            continue
        s=p.lstat()
        assert (s.st_dev, s.st_ino) == (e['dev'], e['inode'])
    for e in plan['candidates']:
        p=Path(e['path'])
        if str(p) in completed:
            assert not p.exists()
            continue
        emit('delete_start', path=str(p), regular_files=e['regular_files'])
        if p.is_dir():
            assert shutil.rmtree.avoids_symlink_attacks
            errors=[]
            def onexc(function, path, error):
                errors.append(dict(path=str(path),error=repr(error)))
            shutil.rmtree(p,onexc=onexc)
            if errors:
                emit('delete_permission_residual', path=str(p), errors=errors)
        else:
            p.unlink()
        if not p.exists():
            emit('deleted', path=str(p))
    os.sync()
    verify()

if __name__ == '__main__':
    {'prepare':prepare, 'apply':apply, 'verify':verify}[sys.argv[1]]()
