"""Append-only scheduler; never changes frozen trainer/controller source bytes."""
import argparse, fcntl, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = Path('/data/patr-storage/golden-ucf-20261103/code')
PYTHON = '/home/vipuser/patr-reproduction/.venv/bin/python'
LOCK = Path('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock')
RANDOM = Path('/data/patr-storage/golden-b3-k2-seed43-20261104/code')
Q = ROOT/'runs/multiseed_queue'
ARCH = ROOT/'runs/ucf_seed_replicates'
LIVE = ROOT/'runs/formal/ucf/code'
BACKUP = Path('/home/vipuser/ucf-artifact-archive-20261104')

def read(p):
    return json.loads(Path(p).read_text()) if Path(p).exists() else {}

def atomic(p, x):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name+'.tmp'); tmp.write_text(json.dumps(x, indent=2)); tmp.replace(p)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024**2), b''): h.update(chunk)
    return h.hexdigest()

def config_diff(a,b):
    return {k: [a.get(k), b.get(k)] for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)}

def prerequisites(root=ROOT, random_root=RANDOM):
    if read(root/'runs/phase2_queue/status.json').get('status')!='complete_all_arms_and_seed43_report': return False
    if read(random_root/'runs/queue/status.json').get('status')!='complete_seed43_stability_report': return False
    report=read(root/'runs/final_comparison.json')
    if set(report.get('completed_ucf_arms',[]))!={'ucf','noIS','uniform'}: return False
    for split,n in [('all500',500),('filtered409',409)]:
        s=report.get('strata',{}).get(split,{})
        if s.get('n_tasks')!=n or 'Random-K2-seed43' not in s.get('models',{}): return False
        for a in ['ucf','noIS','uniform']:
            if 'UCF-'+a not in s.get('models',{}): return False
    for a in ['noIS','uniform']:
        p=root/f'runs/formal/{a}/code/runs/formal/patr_seed42'
        if read(p/'status.json').get('status')!='complete': return False
        if not (p/'final_test.jsonl').exists(): return False
        if not all((p/f'supplemental500/batch{i}.jsonl').exists() for i in range(1,6)): return False
    return True

def status(s, **kw): atomic(Q/'status.json', dict(status=s,pid=os.getpid(),updated=time.time(),**kw))
def gpu(): return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

def verify(plan):
    for name,h in plan['source_sha256'].items(): assert sha(ROOT/name)==h, name
    for name,h in plan['fixed_files_sha256'].items(): assert sha(name)==h, name
    for name in ['cpu_acceptance','gpu_acceptance','phase1_gate']:
        assert read(ROOT/f'artifacts/{name}.json')['passed'],name
    for n in ['runtime_override.json','deadline.json']: assert not (ROOT/'artifacts'/n).exists(),n
    assert plan['actual_seed42']['ucf_beta']==.25
    assert plan['actual_seed42']['ucf_c0']==.2068003796664843
    for name,h in plan['sft_sha256'].items(): assert sha(Path(plan['actual_seed42']['model'])/name)==h,name

def tree_hash(p):
    return {'.':sha(p)} if p.is_file() else {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}

def relocate(p):
    """Copy, verify, journal, then replace completed artifact with an archive symlink."""
    if p.is_symlink() or not p.exists(): return
    dst=BACKUP/p.relative_to(ROOT); dst.parent.mkdir(parents=True,exist_ok=True)
    hashes=tree_hash(p)
    size=p.stat().st_size if p.is_file() else sum(f.stat().st_size for f in p.rglob('*') if f.is_file())
    assert shutil.disk_usage(BACKUP).free > size+4*1024**3, 'Archive disk space insufficient'
    if not dst.exists():
        tmp=dst.with_name(dst.name+'.copying')
        assert not tmp.exists(),f'Preserve interrupted copy for inspection: {tmp}'
        if p.is_dir(): shutil.copytree(p,tmp)
        else: shutil.copy2(p,tmp)
        assert tree_hash(tmp)==hashes
        tmp.rename(dst)
    assert tree_hash(dst)==hashes
    receipt=Q/'relocations'/f'{time.time_ns()}.json'
    atomic(receipt,dict(original=str(p),archive=str(dst),sha256=hashes,backup_verified=True,bytes=size))
    # All bytes already exist and are verified in the archive; retain the original path.
    old=p.with_name(p.name+'.verified_move')
    p.rename(old);p.symlink_to(dst,target_is_directory=dst.is_dir())
    if old.is_dir():shutil.rmtree(old)
    else:old.unlink()

def ensure_space():
    BACKUP.mkdir(parents=True,exist_ok=True)
    candidates=[ARCH/'seed42/code/runs/formal/patr_seed42']
    candidates += [ROOT/f'runs/formal/{v}/code/runs/formal/patr_seed42' for v in ['noIS','uniform']]
    candidates += [ARCH/'seed43/code/runs/formal/patr_seed43',ARCH/'seed44/code/runs/formal/patr_seed44']
    for p in candidates:
        if shutil.disk_usage(ROOT).free>=24*1024**3:return
        if read(p/'status.json').get('status')=='complete':
            for n in ['checkpoint.pt','final_model']:relocate(p/n)
    assert shutil.disk_usage(ROOT).free>=24*1024**3,'Insufficient storage after verified completed-artifact relocation'

def archive(seed):
    dst=ARCH/f'seed{seed}/code'
    if dst.exists():return
    assert LIVE.exists() and not LIVE.is_symlink()
    assert read(LIVE/'config.json')['seed']==seed
    assert read(LIVE/f'runs/formal/patr_seed{seed}/status.json').get('status')=='complete'
    dst.parent.mkdir(parents=True,exist_ok=True); LIVE.rename(dst)
    atomic(Q/f'archive_seed{seed}.json',dict(seed=seed,original=str(LIVE),archive=str(dst),time=time.time()))

def prepare_config(plan,seed):
    cfg=dict(plan['base_seed42'],seed=seed)
    assert config_diff(plan['base_seed42'],cfg)=={'seed':[42,seed]}
    atomic(ROOT/'configs/base.json',cfg)
    actual=dict(plan['actual_seed42'],seed=seed)
    atomic(Q/f'config_seed{seed}.json',actual)
    atomic(Q/f'config_diff_seed{seed}.json',config_diff(plan['actual_seed42'],actual))

def recovery_alias(seed):
    # Frozen run_ucf/ucf_recovery use the old directory name on resume only.
    target=LIVE/f'runs/formal/patr_seed{seed}';alias=target.parent/'patr_seed42'
    assert (target/'checkpoint.pt').exists()
    if alias.is_symlink(): assert alias.resolve()==target.resolve()
    else: assert not alias.exists();alias.symlink_to(target.name,target_is_directory=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');args=parser.parse_args()
    plan=read(HERE/'protocol.json')
    if args.check:
        verify(plan);print(json.dumps({'prerequisites_ready':prerequisites(),'source_and_protocol_verified':True}));return
    Q.mkdir(parents=True,exist_ok=True)
    with (Q/'scheduler.lock').open('a+') as single:
        fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
        while not prerequisites():
            status('waiting_existing_queue_all_tests_and_reports',seeds=[43,44]);time.sleep(30)
        # Never acquire or reserve the GPU lock before the complete predecessor barrier.
        with LOCK.open('a+') as lease:
            while True:
                try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:status('waiting_gpu_lock_after_existing_queue');time.sleep(20);continue
                if not gpu():break
                fcntl.flock(lease,fcntl.LOCK_UN);time.sleep(20)
            assert prerequisites();verify(plan)
            if not (ARCH/'seed42/code').exists():archive(42)
            for seed in [43,44]:
                if (ARCH/f'seed{seed}/code').exists():continue
                verify(plan);ensure_space();prepare_config(plan,seed)
                formal=LIVE/f'runs/formal/patr_seed{seed}'
                if read(formal/'status.json').get('status')=='complete':archive(seed);continue
                resume=(formal/'checkpoint.pt').exists()
                if LIVE.exists() and not resume:
                    assert read(LIVE/'config.json').get('seed')==seed
                    preserved=Q/'recovery'/f'seed{seed}_before_checkpoint_{time.time_ns()}'
                    preserved.parent.mkdir(parents=True,exist_ok=True);LIVE.rename(preserved)
                if resume:recovery_alias(seed)
                cmd=[PYTHON,'-u','run_ucf.py','--variant','ucf','--beta','0.25','--c0','0.2068003796664843']+(['--resume'] if resume else [])
                env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
                with (Q/f'seed{seed}.log').open('a') as log:
                    proc=subprocess.Popen(cmd,cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
                    status('running',seed=seed,child_pid=proc.pid,resume=resume)
                    assert proc.wait()==0,f'seed{seed} failed; previous checkpoint and raw evidence retained'
                for _ in range(60):
                    if not gpu():break
                    time.sleep(2)
                assert not gpu();assert read(formal/'status.json').get('status')=='complete'
                assert config_diff(plan['actual_seed42'],read(LIVE/'config.json'))=={'seed':[42,seed]}
                archive(seed)
                subprocess.run([PYTHON,str(HERE/'report.py')],check=True,cwd=ROOT)
            # Restore the seed42 canonical view after both appended runs.
            (ROOT/'configs/base.json').write_bytes((HERE/'base_seed42.original.json').read_bytes())
            if not LIVE.exists():LIVE.symlink_to(ARCH/'seed42/code',target_is_directory=True)
        subprocess.run([PYTHON,str(HERE/'report.py')],check=True,cwd=ROOT)
        report=read(Q/'report.json');assert report['complete_three_seeds'] and report['paired_seed43_vs_random43']
        status('complete_ucf_seeds42_43_44_and_reports',report=str(Q/'report.json'))

if __name__=='__main__':
    try:main()
    except BlockingIOError:raise SystemExit('Another multiseed scheduler holds its lock')
    except Exception as e:
        status('error_evidence_retained',error=repr(e));raise
