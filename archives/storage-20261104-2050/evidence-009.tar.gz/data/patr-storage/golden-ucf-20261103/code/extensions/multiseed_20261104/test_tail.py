import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import queue_tail as q
import report as r

class TailTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.b=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def fixture(self):
        root=self.b/'root';random=self.b/'random'
        q.atomic(root/'runs/phase2_queue/status.json',{'status':'complete_all_arms_and_seed43_report'})
        q.atomic(random/'runs/queue/status.json',{'status':'complete_seed43_stability_report'})
        q.atomic(root/'runs/final_comparison.json',{'completed_ucf_arms':['ucf','noIS','uniform'],'strata':{s:{'n_tasks':n,'models':{k:{} for k in ['UCF-ucf','UCF-noIS','UCF-uniform','Random-K2-seed43']}} for s,n in [('all500',500),('filtered409',409)]}})
        for a in ['noIS','uniform']:
            p=root/f'runs/formal/{a}/code/runs/formal/patr_seed42'
            q.atomic(p/'status.json',{'status':'complete'});(p/'final_test.jsonl').touch()
            (p/'supplemental500').mkdir()
            for i in range(1,6):(p/f'supplemental500/batch{i}.jsonl').touch()
        return root,random
    def test_barrier_waits_until_reports(self):
        root,random=self.fixture();self.assertTrue(q.prerequisites(root,random))
        p=root/'runs/phase2_queue/status.json';q.atomic(p,{'status':'running'});self.assertFalse(q.prerequisites(root,random))
        q.atomic(p,{'status':'complete_all_arms_and_seed43_report'})
        q.atomic(random/'runs/queue/status.json',{'status':'running'});self.assertFalse(q.prerequisites(root,random))
    def test_missing_final_batch_blocks(self):
        root,random=self.fixture();(root/'runs/formal/uniform/code/runs/formal/patr_seed42/supplemental500/batch5.jsonl').unlink()
        self.assertFalse(q.prerequisites(root,random))
    def test_missing_model_summary_blocks(self):
        root,random=self.fixture();p=root/'runs/final_comparison.json';d=q.read(p);del d['strata']['all500']['models']['UCF-noIS'];q.atomic(p,d)
        self.assertFalse(q.prerequisites(root,random))
    def test_exact_config(self):
        a={'seed':42,'ucf_log_dir':'/unchanged','run_label':'seed42','ucf_beta':.25}
        self.assertEqual(q.config_diff(a,dict(a,seed=43)),{'seed':[42,43]})
        with patch.object(q,'ROOT',self.b),patch.object(q,'Q',self.b/'queue'):
            q.prepare_config({'base_seed42':a,'actual_seed42':a},44)
            self.assertEqual(q.read(self.b/'configs/base.json'),dict(a,seed=44))
    def test_resume_alias_and_frozen_reconcile(self):
        live=self.b/'live';p=live/'runs/formal/patr_seed43';p.mkdir(parents=True);(p/'checkpoint.pt').write_bytes(b'checkpoint')
        with patch.object(q,'LIVE',live):q.recovery_alias(43)
        self.assertEqual((p.parent/'patr_seed42').resolve(),p.resolve())
        import sys
        sys.path.insert(0,str(q.ROOT));from ucf_recovery import reconcile_checkpoint
        q.atomic(live/'ucf_logs/controller_0010.json',{'last_step':10,'history':[2.]*10,'c':.2})
        q.atomic(live/'ucf_logs/controller.json',{'last_step':11,'history':[2.]*11,'c':.3})
        (p/'train_metrics.jsonl').write_text('{"step":10}\n{"step":11}\n')
        (p/'rollouts_0011.jsonl.gz').write_bytes(b'preserve')
        receipt=reconcile_checkpoint(live,10)
        self.assertEqual((p/'train_metrics.jsonl').read_text(),'{"step":10}\n')
        self.assertEqual(q.read(live/'ucf_logs/controller.json')['last_step'],10)
        self.assertTrue(any(x['original'].endswith('rollouts_0011.jsonl.gz') for x in receipt['preserved']))
    def test_archive_is_move_not_overwrite(self):
        live=self.b/'live';arch=self.b/'arch';q.atomic(live/'config.json',{'seed':43});q.atomic(live/'runs/formal/patr_seed43/status.json',{'status':'complete'})
        (live/'evidence').write_bytes(b'unchanged')
        with patch.object(q,'LIVE',live),patch.object(q,'ARCH',arch),patch.object(q,'Q',self.b/'q'):
            q.archive(43);q.archive(43)
        self.assertFalse(live.exists());self.assertEqual((arch/'seed43/code/evidence').read_bytes(),b'unchanged')
    def test_verified_relocation(self):
        root=self.b/'root';p=root/'run/final_model';p.mkdir(parents=True);(p/'weights').write_bytes(b'evidence')
        with patch.object(q,'ROOT',root),patch.object(q,'BACKUP',self.b/'backup'),patch.object(q,'Q',self.b/'q'):
            q.relocate(p)
        self.assertTrue(p.is_symlink());self.assertEqual((p/'weights').read_bytes(),b'evidence')
    def test_pairing_and_bootstrap(self):
        a={str(i):[{'reward':1}]*4 for i in range(20)};b={k:[{'reward':0}]*4 for k in a}
        self.assertEqual(r.paired(a,a,sorted(a))['success_ci95_pp'],[0.,0.])
        self.assertEqual(r.paired(a,b,sorted(a))['success_ci95_pp'],[100.,100.])
    def test_sd(self):
        x=r.seed_stats([1,2,3]);self.assertEqual(x['mean'],2);self.assertEqual(x['sample_std'],1)
    def test_strata_are_complete(self):
        u=[str(i) for i in range(500)];geo={x:{'shortest_path':[3,5,7,10,None][int(x)%5],'detour':int(x)%2==1} for x in u}
        s=r.strata(u,geo,set(u[:91]));self.assertEqual(len(s['filtered409']),409)
        self.assertEqual(sum(len(v) for k,v in s.items() if k.startswith('length_')),500)
        self.assertEqual(len(s['detour_true'])+len(s['detour_false']),500)
if __name__=='__main__':unittest.main()
