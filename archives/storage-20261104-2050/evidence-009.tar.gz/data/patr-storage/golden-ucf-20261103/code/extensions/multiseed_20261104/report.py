"""Frozen report-only three-seed summary and task-paired seed43 benchmark."""
import hashlib,json,math,statistics
from pathlib import Path
import numpy as np
from queue_tail import ROOT,ARCH,LIVE,Q,RANDOM,HERE,read,atomic,config_diff,sha

def groups(paths):
    g={}
    for p in paths:
        for line in p.open():
            r=json.loads(line);g.setdefault(r['task']['uid'],[]).append(r)
    assert g and all(len(v)==4 and len({r['lineage'] for r in v})==4 for v in g.values())
    return g

def summary(g,us):
    if not us:return None
    return dict(n_tasks=len(us),n_trajectories=4*len(us),success_rate_pct=100*sum(sum(r['reward']>0 for r in g[u]) for u in us)/(4*len(us)),pass_at_4_pct=100*sum(any(r['reward']>0 for r in g[u]) for u in us)/len(us))

def paired(a,b,us):
    if not us:return None
    assert all(u in a and u in b for u in us)
    rng=np.random.default_rng(20261103)
    d=np.array([[sum(r['reward']>0 for r in a[u])/4-sum(r['reward']>0 for r in b[u])/4,int(any(r['reward']>0 for r in a[u]))-int(any(r['reward']>0 for r in b[u]))] for u in us])
    bs=[]
    for _ in range(100):bs.append(d[rng.integers(len(us),size=(100,len(us)))].mean(axis=1))
    z=np.concatenate(bs)*100
    return dict(n_tasks=len(us),replicates=10000,bootstrap_seed=20261103,resampling_unit='task; all four trajectories retained',success_delta_pp=float(d[:,0].mean()*100),success_ci95_pp=np.quantile(z[:,0],[.025,.975]).tolist(),pass4_delta_pp=float(d[:,1].mean()*100),pass4_ci95_pp=np.quantile(z[:,1],[.025,.975]).tolist())

def strata(uids,geometry,excluded):
    out={'all500':sorted(uids),'filtered409':sorted(set(uids)-excluded)}
    assert len(out['all500'])==500 and len(out['filtered409'])==409
    for name,lo,hi in [('length_le3',0,3),('length_4_5',4,5),('length_6_7',6,7),('length_8_10',8,10)]:
        out[name]=[u for u in sorted(uids) if geometry[u]['shortest_path'] is not None and lo<=geometry[u]['shortest_path']<=hi]
    covered=set().union(*(set(v) for k,v in out.items() if k.startswith('length_')))
    out['length_other']=sorted(set(uids)-covered)
    for flag in [False,True]:out['detour_'+str(flag).lower()]=[u for u in sorted(uids) if geometry[u]['detour']==flag]
    return out

def seed_stats(values):
    return dict(n_seeds=len(values),mean=statistics.mean(values),sample_std=statistics.stdev(values) if len(values)>1 else None,ddof=1)

def curves(code,seed):
    p=code/f'runs/formal/patr_seed{seed}'
    metrics=[json.loads(x) for x in (p/'train_metrics.jsonl').read_text().splitlines()]
    assert [x['step'] for x in metrics]==list(range(1,401))
    entropy={}
    for line in (p/'branch_events.jsonl').open():
        row=json.loads(line);es=[e for e in row['events'] if e.get('kind')=='ucf_fork']
        entropy[row['step']]={k:statistics.mean([e[k] for e in es]) if es else None for k in ['H_act','H_cons']}
        entropy[row['step']]['selected_node_count']=len(es)
    vals={int(f.stem.split('_')[-1]):read(f) for f in sorted(p.glob('validation_*.json'))}
    assert set(vals)==set(range(0,401,25))
    out=[];gen=inp=actor=0
    for r in metrics:
        gen+=r['generated_tokens'];inp+=r['input_tokens'];actor+=r['probe_cost']['input_tokens']
        ent=entropy[r['step']];assert ent['selected_node_count']==r['branch_events']
        assert len(r['fork_counts'])==64
        out.append(dict(step=r['step'],sampling_success_rate=r['success_rate'],mixed_group_fraction=r['mixed_group_fraction'],validation=vals.get(r['step']),fork_count=r['branch_events'],mean_forks=r['mean_forks'],fork_counts=r['fork_counts'],c_step=r['c_step'],c_next=r['c_next'],rho_values=r['rho_values'],counterfactual_flip_rate=r['counterfactual_flip_rate'],selected_node_entropy=ent,initial_token_entropy_mc_nats=r['rollout_sampled_surprisal'],generated_tokens=r['generated_tokens'],input_tokens=r['input_tokens'],actor_scoring_input_tokens=r['probe_cost']['input_tokens'],cumulative_generated_tokens=gen,cumulative_input_tokens=inp,cumulative_actor_scoring_input_tokens=actor,step_seconds=r['step_seconds'],grad_norm=r['grad_norm'],kl=r['kl']))
    return dict(seed=seed,initial_validation=vals[0],entropy_definition='H_act/H_cons: exact existing normalized entropy at selected fork nodes only; selection-biased, not all candidates. initial_token_entropy_mc_nats: on-policy sampled negative log probability, a Monte Carlo entropy estimate, not exact full-vocabulary entropy.',steps=out,totals=dict(generated_tokens=gen,input_tokens=inp,actor_scoring_input_tokens=actor,training_seconds=sum(r['step_seconds'] for r in metrics)))

def main():
    plan=read(HERE/'protocol.json');runs={}
    for seed in [42,43,44]:
        code=ARCH/f'seed{seed}/code'
        if not code.exists() and read(LIVE/'config.json').get('seed')==seed:code=LIVE
        p=code/f'runs/formal/patr_seed{seed}'
        if read(p/'status.json').get('status')=='complete':runs[seed]=(code,p)
    assert 42 in runs
    geometry=read(ROOT/'runs/g2_evaluation/report.json')['geometry']
    excluded=set(read('/home/vipuser/golden-controls-20261031/code/runs/audit/overlap_report.json')['excluded_uids'])
    report=dict(complete_three_seeds=set(runs)=={42,43,44},available_seeds=sorted(runs),no_test_selection=True,three_seed_mean_std=None,per_seed={},paired_seed43_vs_random43=None,limitations=['Three UCF training seeds; sample SD uses ddof=1.','Task-paired bootstrap is conditional on the two seed43 trained models, not a training-seed confidence interval.','filtered409 is the fixed overlap sensitivity cohort.'],phase1_policy_disclosure=plan['phase1_policy_disclosure'])
    all_groups={};strat=None
    for seed,(code,p) in runs.items():
        expected=dict(plan['actual_seed42'],seed=seed)
        assert read(code/'config.json')==expected
        for name in ['train.py','patr_core.py']:assert sha(code/name)==plan['source_sha256'][name]
        g=groups([p/f'supplemental500/batch{i}.jsonl' for i in range(1,6)]);all_groups[seed]=g
        if strat is None:strat=strata(g,geometry,excluded)
        assert set(g)==set(strat['all500'])
        main_g=groups([p/'final_test.jsonl']);assert len(main_g)==100
        report['per_seed'][str(seed)]={'main100':summary(main_g,sorted(main_g)),**{k:summary(g,us) for k,us in strat.items()}}
        c=curves(code,seed);atomic(Q/f'curves_seed{seed}.json',c)
        report['per_seed'][str(seed)]['token_cost']=c['totals']
    if report['complete_three_seeds']:
        report['three_seed_mean_std']={split:{metric:seed_stats([report['per_seed'][str(seed)][split][metric] for seed in [42,43,44]]) for metric in ['success_rate_pct','pass_at_4_pct']} for split in ['main100',*strat] if report['per_seed']['42'][split] is not None}
    if 43 in runs:
        assert read(RANDOM/'runs/queue/status.json').get('status')=='complete_seed43_stability_report'
        other=groups([RANDOM/f'runs/supplemental500/batch{i}.jsonl' for i in range(1,6)])
        assert set(other)==set(strat['all500'])
        report['paired_seed43_vs_random43']={k:paired(all_groups[43],other,us) for k,us in strat.items()}
        report['random_k2_seed43']={k:summary(other,us) for k,us in strat.items()}
    atomic(Q/'report.json',report)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(4,2,figsize=(14,15),constrained_layout=True)
    for seed in runs:
        rows=read(Q/f'curves_seed{seed}.json')['steps'];x=[r['step'] for r in rows];label=f'seed{seed}'
        for ax,key,title in [(axs[0,0],'sampling_success_rate','Initial sampling success'),(axs[1,0],'mean_forks','Forks per task'),(axs[1,1],'c_step','Controller c_step'),(axs[2,0],'counterfactual_flip_rate','Counterfactual flip rate'),(axs[3,0],'initial_token_entropy_mc_nats','Initial token entropy: MC estimate (nats)')]:
            ax.plot(x,[r[key] for r in rows],label=label,alpha=.8);ax.set_title(title)
        vs=[r for r in rows if r['validation']];axs[0,1].plot([r['step'] for r in vs],[r['validation']['success_rate_pct'] for r in vs],label=label);axs[0,1].set_title('Fixed validation success (%)')
        for k,style in [('H_act','-'),('H_cons','--')]:axs[2,1].plot(x,[r['selected_node_entropy'][k] for r in rows],style,label=label+' '+k)
        axs[2,1].set_title('Selected-node normalized entropy')
        axs[3,1].plot(x,[r['cumulative_generated_tokens']/1e6 for r in rows],label=label+' generation')
        axs[3,1].plot(x,[r['cumulative_actor_scoring_input_tokens']/1e6 for r in rows],'--',label=label+' actor input');axs[3,1].set_title('Cumulative tokens (millions)')
    for ax in axs.flat:ax.set_xlabel('Training step');ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(Q/'training_curves.png',dpi=160);fig.savefig(Q/'training_curves.svg');plt.close(fig)
    print(json.dumps({'available_seeds':sorted(runs),'complete':report['complete_three_seeds'],'report':str(Q/'report.json')}))

if __name__=='__main__':main()
