"""Predeclared paired Monte Carlo intervals; never reads validation/test."""
import itertools,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
MODELS=['sft','grpo400','random400'];BETAS=[.25,.5,1.]
def bootstrap(values,indices):return values[indices].mean(axis=(1,2))
def main():
 data={m:[json.loads((ROOT/f'runs/phase1/{m}/b{b}_r{r}/result.json').read_text()) for b in range(1,4) for r in range(1,5)] for m in MODELS}
 rng=np.random.default_rng(20261103)
 # Stratify the 3 fixed batches; reuse indices across models and estimators.
 ix=np.stack([rng.integers(0,4,size=(10000,4))+4*b for b in range(3)],axis=1)
 def ci(v):return np.quantile(bootstrap(np.asarray(v),ix),[.025,.975]).tolist()
 vals={};table={}
 for m,rows in data.items():
  vals[m]={};table[m]={}
  for e in rows[0]['estimators']:
   cos=[r['estimators'][e]['cosines'][0] for r in rows];mse=[r['estimators'][e]['relative_mse'][0] for r in rows]
   if any(v is not None and not np.isfinite(v) for v in cos+mse):
    raise ValueError('Nonfinite gradient metric: '+m+'/'+e)
   if any(v is None for v in cos+mse):
    # Standalone zero-gradient diagnostics are not admission estimators.
    if e not in ['Braw','Bht','Bcf'] or any(v is None for v in mse) or any(c is None and r['estimators'][e]['norm2']!=0 for c,r in zip(cos,rows)):
     raise ValueError('Undefined gradient metric; cannot pass gate: '+m+'/'+e)
    table[m][e]=dict(mean_cosine=None,cosine_ci95=None,mean_relative_mse=float(np.mean(mse)),relative_mse_ci95=ci(mse),n_repeats=len(rows),undefined_cosine_repeats=[dict(batch=i//4+1,repeat=i%4+1,norm2=rows[i]['estimators'][e]['norm2']) for i,c in enumerate(cos) if c is None],reason='Zero diagnostic gradient; full-sample cosine mean and interval undefined; no repeats removed')
    continue
   vals[m][e]=np.array(cos);table[m][e]=dict(mean_cosine=float(np.mean(cos)),cosine_ci95=ci(cos),mean_relative_mse=float(np.mean(mse)),relative_mse_ci95=ci(mse))
  table[m]['paired_comparisons']={}
  for beta in BETAS:
   e=f'A+{beta:g}*Bcf'
   for comparator in ['CERT-uniform','GRPO4','CERT-uct']:
    delta=vals[m][e]-vals[m][comparator]
    table[m]['paired_comparisons'][e+'_minus_'+comparator]=dict(mean=float(delta.mean()),ci95=ci(delta),primary=comparator=='CERT-uniform')
  table[m]['half_reference_reliability']=[r['half_reference_cosine'] for r in rows]
 candidates=[];checks=[]
 for beta in BETAS:
  e=f'A+{beta:g}*Bcf'
  qualified=[m for m in MODELS if vals[m][e].mean()>vals[m]['GRPO4'].mean() and vals[m][e].mean()>vals[m]['CERT-uct'].mean()]
  pairs=[]
  for pair in itertools.combinations(qualified,2):
   diff=np.mean([vals[m][e]-vals[m]['GRPO4'] for m in pair],axis=0);interval=ci(diff)
   pairs.append(dict(models=pair,delta_mean=float(diff.mean()),ci95=interval,passed=interval[0]>0,paired_repeats=24))
  passed=any(p['passed'] for p in pairs);checks.append(dict(beta=beta,qualified_models=qualified,pairs=pairs,passed=passed))
  if passed:candidates.append((float(np.mean([vals[m][e].mean() for m in MODELS])),beta))
 selected=sorted(candidates,key=lambda x:(-x[0],x[1]))[0][1] if candidates else None
 report=dict(primary_reported_comparator='CERT-uniform',separate_benchmark='B3 Random K=2',predeclared_gate_comparator='CERT-uct',passed=bool(candidates),beta=selected,checks=checks,table=table,interval_method='10000 paired bootstrap replicates; fixed-batch strata; shared repeat indices across models',inference_scope='Monte Carlo variation conditional on fixed training tasks and checkpoints; beta/model-pair selection means nominal intervals are exploratory, not independent confirmatory evidence',tie_rule='Highest cosine averaged across all three models, exact ties choose smaller beta',no_test_or_validation_use=True)
 (ROOT/'artifacts/phase1_gate.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='table'},indent=2))
if __name__=='__main__':main()
