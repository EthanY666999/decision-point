"""CPU regression: diagnostic zero vectors cannot alter admission decisions."""
import contextlib, io, json, tempfile
from pathlib import Path

def verify(original, revised):
    names=['GRPO4','CERT-uniform','CERT-uct','A+0.25*Bcf','A+0.5*Bcf','A+1*Bcf','Braw','Bht','Bcf']
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);(root/'artifacts').mkdir()
        def write(undefined=None, norm=0):
            for model in ['sft','grpo400','random400']:
                for b in range(1,4):
                    for r in range(1,5):
                        es={n:dict(cosines=[.8 if n.startswith('A+') else .5]*3,relative_mse=[1.]*3,norm2=1.) for n in names}
                        if undefined and b==1 and r==2:
                            es[undefined].update(cosines=[None]*3,norm2=norm)
                        p=root/f'runs/phase1/{model}/b{b}_r{r}/result.json';p.parent.mkdir(parents=True,exist_ok=True)
                        p.write_text(json.dumps(dict(estimators=es,half_reference_cosine=.9)))
        def run(source):
            namespace={'__file__':str(root/'scripts/phase1_gate.py'),'__name__':'gate_test'}
            exec(compile(source,'phase1_gate.py','exec'),namespace)
            with contextlib.redirect_stdout(io.StringIO()):namespace['main']()
            return json.loads((root/'artifacts/phase1_gate.json').read_text())
        write();before=run(original);after=run(revised)
        assert before==after
        write('Bht');after=run(revised)
        assert all(before[k]==after[k] for k in ['passed','beta','checks'])
        for m in ['sft','grpo400','random400']:
            d=after['table'][m]['Bht'];assert d['mean_cosine'] is None and d['n_repeats']==12 and d['mean_relative_mse']==1.
            assert d['undefined_cosine_repeats']==[dict(batch=1,repeat=2,norm2=0)]
        for name,norm in [('GRPO4',0),('Bht',1)]:
            write(name,norm)
            try:run(revised)
            except ValueError:pass
            else:raise AssertionError('Undefined metric unexpectedly admitted: '+name)
    print('PASS: unchanged finite gate, retained zero diagnostic, rejected undefined required metric, rejected unexplained null')
