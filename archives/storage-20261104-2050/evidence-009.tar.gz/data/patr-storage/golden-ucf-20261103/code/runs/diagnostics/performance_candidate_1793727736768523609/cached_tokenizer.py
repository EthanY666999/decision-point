"""Candidate adapter for a tokenizer whose vocabulary is fixed after loading.

Staged only: integrate at a safe process boundary after GPU equivalence checks.
"""
class CachedLengthTokenizer:
    def __init__(self, tokenizer):
        self._tokenizer = tokenizer
        self._size = len(tokenizer)

    def __len__(self):
        return self._size

    def __getattr__(self, name):
        return getattr(self._tokenizer, name)

    def __call__(self, *args, **kwargs):
        return self._tokenizer(*args, **kwargs)

    def add_tokens(self, *args, **kwargs):
        result = self._tokenizer.add_tokens(*args, **kwargs)
        self._size = len(self._tokenizer)
        return result

    def add_special_tokens(self, *args, **kwargs):
        result = self._tokenizer.add_special_tokens(*args, **kwargs)
        self._size = len(self._tokenizer)
        return result
