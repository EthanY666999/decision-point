"""GPU equivalence acceptance, to run only when holding the shared GPU lease.

Does not update parameters, modify active source, or write a Phase1 gate.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = Path('/data/patr-storage/golden-ucf-20261103/code')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from cached_tokenizer import CachedLengthTokenizer


def main():
    os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']))
    import patr_core as core
    import train
    cfg = json.loads((ROOT / 'configs/base.json').read_text())
    cfg.update(initial_branches=32, branch_interval=cfg['max_turns'] + 1)
    tasks = json.loads((ROOT / 'artifacts/data.json').read_text())['train'][:4]
    actor, ref, engine, tokenizer = train.build_models(cfg, 42)
    cached = CachedLengthTokenizer(tokenizer)
    evidence = ROOT / 'runs/diagnostics' / ('cache_gpu_' + str(time.time_ns()))
    evidence.mkdir(parents=True)
    results = {}
    for name, tok in [('original', tokenizer), ('cached', cached)]:
        engine.llm_engine.reset_prefix_cache()
        started = time.monotonic()
        branches, stats, events = core.collect(
            tasks, engine, tok, cfg, 'patr', np.random.default_rng(20261104))
        elapsed = time.monotonic() - started
        train.write_rollouts(evidence / (name + '.jsonl.gz'), branches, tasks)
        rows = [dict(task_id=b.task_id, lineage=b.lineage, ids=b.ids, mask=b.mask,
                     old_logprobs=b.old_logprobs, reward=b.reward,
                     terminal=b.terminal, trace=b.trace, actions=b.actions,
                     entropy=b.entropy, initial_entropy=b.initial_entropy)
                for b in branches]
        digest = hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()
        results[name] = dict(seconds=elapsed, sha256=digest,
                             trajectories=len(branches), stats=stats)
    passed = (results['original']['trajectories'] == 128
              and results['cached']['trajectories'] == 128
              and results['original']['sha256'] == results['cached']['sha256'])
    receipt = dict(passed=passed, results=results, weights_updated=False,
                   source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in [HERE / 'cached_tokenizer.py', Path(__file__)]})
    (evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(dict(path=str(evidence), **receipt), indent=2))
    assert passed, 'Cached tokenizer changed sampled trajectories; preserve evidence'


if __name__ == '__main__':
    main()
