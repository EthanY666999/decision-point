import unittest
from cached_tokenizer import CachedLengthTokenizer


class FakeTokenizer:
    def __init__(self):
        self.size = 100
        self.length_calls = 0
        self.pad_token_id = 7

    def __len__(self):
        self.length_calls += 1
        return self.size

    def __call__(self, text, **kwargs):
        return (text, kwargs)

    def add_tokens(self, tokens, **kwargs):
        self.size += len(tokens)
        return len(tokens)

    def add_special_tokens(self, tokens, **kwargs):
        self.size += len(tokens)
        return len(tokens)


class CachedTokenizerTest(unittest.TestCase):
    def test_length_avoids_repeated_backend_queries(self):
        tokenizer = FakeTokenizer()
        cached = CachedLengthTokenizer(tokenizer)
        self.assertEqual([len(cached) for _ in range(1000)], [100] * 1000)
        self.assertEqual(tokenizer.length_calls, 1)

    def test_delegates_attributes_and_calls(self):
        tokenizer = FakeTokenizer()
        cached = CachedLengthTokenizer(tokenizer)
        self.assertEqual(cached.pad_token_id, tokenizer.pad_token_id)
        self.assertEqual(cached('x', padding=True), tokenizer('x', padding=True))

    def test_vocabulary_mutations_refresh_cache(self):
        tokenizer = FakeTokenizer()
        cached = CachedLengthTokenizer(tokenizer)
        self.assertEqual(cached.add_tokens(['a', 'b']), 2)
        self.assertEqual(len(cached), 102)
        self.assertEqual(cached.add_special_tokens({'eos_token': 'end'}), 1)
        self.assertEqual(len(cached), 103)


if __name__ == '__main__':
    unittest.main()
