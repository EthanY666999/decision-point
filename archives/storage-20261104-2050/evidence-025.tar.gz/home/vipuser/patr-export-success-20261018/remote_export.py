import hashlib, io, json, os, re, stat, subprocess, sys, tarfile, threading, time
from pathlib import Path
BASE=Path('/home/vipuser/patr-export-success-20261018')

class HashReader:
 def __init__(self,f):self.f=f;self.h=hashlib.sha256()
 def read(self,n=-1):
  b=self.f.read(n);self.h.update(b);return b

def export(name):
 doc=json.loads((BASE/'inventory.json').read_text())
 entries=[e for e in doc['entries'] if e['group']==name]
 compressor=subprocess.Popen(['zstd','-q','-1','-T4','-c'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 compressed_hash=hashlib.sha256(); compressed_bytes=0; errors=[]
 def pump():
  nonlocal compressed_bytes
  try:
   while True:
    b=compressor.stdout.read(1024**2)
    if not b:break
    compressed_hash.update(b);compressed_bytes+=len(b);sys.stdout.buffer.write(b)
   sys.stdout.buffer.flush()
  except Exception as ex:errors.append(str(ex))
 thread=threading.Thread(target=pump);thread.start()
 manifest=[]; inodes={}
 try:
  with tarfile.open(fileobj=compressor.stdin, mode='w|', format=tarfile.PAX_FORMAT) as tar:
   for e in entries:
    p=Path(e['path']);s=p.lstat()
    if (s.st_size,s.st_mtime_ns)!=(e['size'],e['mtime_ns']):raise RuntimeError('Source changed before export: '+str(p))
    info=tar.gettarinfo(str(p),arcname=e['arcname']); row=dict(e)
    if info.isreg():
     key=(s.st_dev,s.st_ino)
     if key in inodes:
      info.type=tarfile.LNKTYPE;info.linkname=inodes[key]['arcname'];info.size=0;row['sha256']=inodes[key]['sha256'];row['hardlink_to']=info.linkname;tar.addfile(info)
     else:
      with p.open('rb') as f:
       reader=HashReader(f);tar.addfile(info,reader);row['sha256']=reader.h.hexdigest()
      inodes[key]=row
    elif info.islnk():
     old=inodes.get((s.st_dev,s.st_ino));row['sha256']=old['sha256'] if old else None;row['hardlink_to']=info.linkname;tar.addfile(info)
    else:tar.addfile(info)
    after=p.lstat()
    if (after.st_size,after.st_mtime_ns)!=(e['size'],e['mtime_ns']):raise RuntimeError('Source changed during export: '+str(p))
    manifest.append(row)
   metadata={'bundle':name,'entries':manifest,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'excluded':doc['excluded']}
   data=json.dumps(metadata,ensure_ascii=False,indent=2).encode()
   info=tarfile.TarInfo('_BACKUP_METADATA/'+name+'.manifest.json');info.size=len(data);info.mode=0o600;tar.addfile(info,io.BytesIO(data))
   for filename in ['environment.json']:
    tar.add(BASE/filename,arcname='_BACKUP_METADATA/'+filename)
  compressor.stdin.close();thread.join();rc=compressor.wait()
  if rc or errors:raise RuntimeError('Compression/transport error '+str((rc,errors)))
  receipt={'bundle':name,'sha256':compressed_hash.hexdigest(),'bytes':compressed_bytes,'entry_count':len(manifest),'source_regular_bytes':sum(e['size'] for e in manifest if e['type']=='file')}
  (BASE/(name+'.manifest.json')).write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
  (BASE/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2))
  print('EXPORT_RECEIPT '+json.dumps(receipt),file=sys.stderr,flush=True)
 except BaseException:
  compressor.kill();raise


if __name__=='__main__':
 assert len(sys.argv)==3 and sys.argv[1]=='export'
 export(sys.argv[2])
