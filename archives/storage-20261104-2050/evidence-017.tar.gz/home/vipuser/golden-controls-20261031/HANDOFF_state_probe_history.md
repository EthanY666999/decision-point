# 补充诊断：带一轮历史的状态探针（给 Codex）

## 背景
现有状态探针（`runs/audit/state_probe/*`）使用全新上下文，被测的那一步相当于第 1 回合。旧 PaTR 在第 1 回合有固定习惯：输出缺一个反引号的无效格式。所以它在探针里 1000/1000 不合法（0%），完全测不出决策水平。这是探针设计的盲点，不是模型本身的结论。

原始模型在贪心解码下有 295/1000 次写到 10240 token 上限。这只影响原始模型这一项参照，不需要重跑。

## 不冲突原则（最重要）
1. 不得与正在进行的队列同时占用 GPU。当前队列是 `tree_random_400` → 固定评估 → GRPO-group4。新探针只在 GPU 空闲时运行：
   - 优先：队列全部结束之后；
   - 或者：`tree_random_400` 的固定评估完成、GRPO-group4 启动之前，如果 supervisor 支持在这一步插入短任务。
   
   不要为了插入新探针去暂停、重启或修改任何正在运行的训练。
2. 不修改以下内容：`train.py`、`patr_core.py`、`configs/*`、`scripts/state_probe.py`、`runs/audit/state_manifest.json`，以及任何已有的 `runs/audit/state_probe/*` 结果。
3. 新代码另起文件 `scripts/state_probe_hist.py`，结果写到新目录 `runs/audit/state_probe_hist1/<label>/`。
4. 所有模型只读加载，不保存权重，不参与任何训练或选型。

## 探针设计
- 状态集合：沿用同一份 `state_manifest.json`（1000 个状态，SHA 不变）。
- 对每个被测状态 s，构造**一轮真实历史**，让被测这一步成为第 2 回合：
  1. 选一个与 s 相邻、不是洞、能一步走到 s 的前驱格 p。有多个时用固定种子随机选（种子 = hash(state id)）；如果没有合法前驱，记录并跳过，并在汇总中列出跳过数。
  2. 历史 = 系统提示 + 第 1 回合的观测（玩家在 p）+ assistant 回答 "\`\`\`<从 p 到 s 的动作>\`\`\`" + 环境返回的第 2 回合观测（玩家在 s）。
  3. 历史文本必须用训练时同一个 `FrozenLakeAgent` 的 `update_from_env` / `update_from_model` 生成，保证格式与训练完全一致。
  4. 被测输出是模型在 s 处的下一个动作。
- 解码：贪心（temperature=0、top_p=1），与原探针相同。**单步 `max_tokens` 改为 1024**，在 summary 和 identity 中注明。
- 统计口径与原探针相同：格式合法率、合法时选中最优动作的比例、全部状态的最优动作率、finish_reason 分布。另外按"训练集中是否出现过该地图几何"分开报告。

## 要测的模型（按顺序，全部只读）
1. 旧 PaTR（无 SFT，400 步）
2. SFT
3. SFT→GRPO 400
4. SFT→PaTR 400
5. SFT→PaTR 500
6. SFT→Tree-Random 400（队列训练完成后再测）
7. 原始模型（可选，放最后；单步上限 1024 后预计几分钟）

## 汇总
- 新建 `runs/audit/state_probe_hist1/summary_table.json`，以及一张表：每个模型的「无历史探针」和「一轮历史探针」并列。
- 结论边界：这是固定状态上的单步诊断，不是对局成功率；只用于区分格式改善和决策改善，不用于选超参数或 checkpoint。

## 完成后报告
- 每个模型两种探针口径的数值；跳过的状态数；耗时；是否与队列发生过 GPU 重叠（应当为否）。
