"""Read-only audit of completed GRPO rollouts; never generates model samples."""
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from patr_core import atomic_json, make_env
from rllm.agents.frozenlake_agent import FrozenLakeAgent


def main():
    through = int(sys.argv[1])
    cfg = json.loads((ROOT / 'configs/frozenlake_05b.json').read_text())
    data_path = ROOT / 'artifacts/data.json'
    manifest = json.loads((ROOT / 'artifacts/data_manifest.json').read_text())
    assert hashlib.sha256(data_path.read_bytes()).hexdigest() == manifest['sha256']
    data = json.loads(data_path.read_text())['train']
    run = ROOT / 'runs/formal/grpo_seed42'
    history = {r['step']: r for r in map(json.loads, (run / 'train_metrics.jsonl').read_text().splitlines())}
    parser = FrozenLakeAgent(max_steps=cfg['max_turns'])
    audited = []
    start = time.time()
    for step in range(1, through + 1):
        metric = history[step]
        rng = np.random.default_rng(np.random.SeedSequence([cfg['seed'], step, 1701]))
        expected = {data[i]['uid']: data[i] for i in rng.choice(len(data), cfg['train_batch_size'], replace=False)}
        assert len(expected) == 64, (step, 'expected task count')
        path = run / f'rollouts_{step:04d}.jsonl.gz'
        groups = collections.defaultdict(list)
        terminals = collections.Counter()
        tokens = actions = invalid = successes = count = 0
        with gzip.open(path, 'rt') as handle:
            for line in handle:
                record = json.loads(line)
                task = record['task']
                assert task == expected.get(task['uid']), (step, task['uid'], 'task stream')
                groups[task['uid']].append(record['lineage'])
                assert record['resample_attempt'] is None, (step, 'unexpected resampling')
                ids, mask, old = record['ids'], record['mask'], record['old_logprobs']
                assert len(ids) == len(mask) == len(old), (step, 'token alignment')
                assert set(mask) <= {0, 1}, (step, 'mask')
                ntokens = sum(mask)
                assert 0 < ntokens <= cfg['max_response_tokens'], (step, 'response budget')
                assert len(ids) <= cfg['max_context_tokens'], (step, 'context budget')
                assert all(math.isfinite(lp) for m, lp in zip(mask, old) if m), (step, 'logprob')
                env = make_env(task, cfg)
                reward = 0.0
                turns = 0
                done = False
                for trace in record['trace']:
                    if trace['action'] is None:
                        assert trace.get('terminal') == 'token_limit', (step, 'unexecuted response')
                        continue
                    assert not done, (step, 'action after termination')
                    action = int(parser._parse_model_response(trace['response'])[1])
                    assert action == trace['action'], (step, 'action parse')
                    observation, earned, done, _ = env.step(action)
                    assert int(env.s) == trace['state'], (step, 'state replay')
                    assert observation == trace['observation'], (step, 'observation replay')
                    assert earned == trace['reward'], (step, 'reward replay')
                    reward += earned
                    turns += 1
                    actions += 1
                    invalid += action == 0
                terminal = record['terminal']
                assert terminal in {'success', 'hole', 'turn_limit', 'token_limit', 'context_limit'}, (step, terminal)
                assert reward == record['reward'], (step, 'outcome reward')
                assert turns <= cfg['max_turns'], (step, 'turn budget')
                assert (terminal == 'success') == bool(env.success()), (step, 'success terminal')
                if terminal == 'hole':
                    assert done and not env.success(), (step, 'hole terminal')
                elif terminal == 'turn_limit':
                    assert not done and turns == cfg['max_turns'], (step, 'turn terminal')
                tokens += ntokens
                successes += reward > 0
                terminals[terminal] += 1
                count += 1
        assert set(groups) == set(expected), (step, 'coverage')
        assert all(len(g) == 8 and set(g) == set(map(str, range(8))) for g in groups.values()), (step, '8 roots')
        assert count == metric['episodes'] == 512, (step, 'trajectory count')
        assert tokens == metric['generated_tokens'] == metric['weighted_response_tokens'], (step, 'tokens')
        assert actions == metric['executed_actions'], (step, 'action count')
        assert invalid == metric['invalid_actions'], (step, 'invalid count')
        assert dict(terminals) == metric['terminal_counts'], (step, 'terminal counts')
        assert math.isclose(successes / count, metric['success_rate'], abs_tol=1e-12), (step, 'success metric')
        assert math.isclose(tokens / count, metric['mean_response_tokens'], abs_tol=1e-12), (step, 'length metric')
        assert math.isclose(actions / count, metric['mean_turns'], abs_tol=1e-12), (step, 'turn metric')
        assert all(math.isfinite(metric[k]) for k in ('loss', 'kl', 'grad_norm', 'max_parameter_change')), (step, 'finite update')
        assert metric['max_parameter_change'] > 0, (step, 'no parameter update')
        audited.append(dict(step=step, tasks=len(groups), trajectories=count, tokens=tokens,
                            actions=actions, rollouts_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        if step % 20 == 0:
            print(json.dumps(dict(audited_through=step, elapsed_seconds=time.time() - start)), flush=True)
    result = dict(status='verified', method='grpo', through_step=through, updated_unix=time.time(),
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  data_sha256=manifest['sha256'], trajectories=sum(x['trajectories'] for x in audited),
                  checks=['fixed task stream', '64 tasks x 8 roots per step', 'response/context/turn budgets',
                          'token-mask-logprob alignment', 'finite sampled logprobs', 'environment action replay',
                          'reward and terminal replay', 'training aggregate metrics', 'finite nonzero updates'],
                  steps=audited, seconds=time.time() - start)
    atomic_json(ROOT / 'reports/grpo_training_trajectory_audit.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'steps'}), flush=True)


if __name__ == '__main__':
    main()
