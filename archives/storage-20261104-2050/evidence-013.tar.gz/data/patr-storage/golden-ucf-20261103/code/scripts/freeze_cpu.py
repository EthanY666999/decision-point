"""Run gates and bind their evidence to exact adapter bytes."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
 subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_ucf.py','-v'],cwd=ROOT,check=True)
 subprocess.run([sys.executable,'tests/htsim_regression.py'],cwd=ROOT,check=True)
 frozen={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['train.py','patr_core.py']}
 for prefix in ['/home/vipuser/golden-cert-20261102-r1/code','/home/vipuser/golden-next-20261031/b2/code','/home/vipuser/golden-next-20261031/b3/code']:
  for n,h in frozen.items():assert hashlib.sha256((Path(prefix)/n).read_bytes()).hexdigest()==h
 sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in list(ROOT.glob('*.py'))+list((ROOT/'scripts').glob('*.py'))}
 (ROOT/'artifacts/frozen.json').write_text(json.dumps(dict(frozen_base=frozen,source_sha256=sources),indent=2))
 (ROOT/'artifacts/cpu_acceptance.json').write_text(json.dumps(dict(passed=True,source_sha256=sources,unittest_count=13,htsim=json.loads((ROOT/'artifacts/htsim_result.json').read_text()),time=time.time()),indent=2))
if __name__=='__main__':main()
