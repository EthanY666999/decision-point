"""Phase1 gate with timestamped user-authorized undefined-cosine amendment."""
import hashlib
import itertools
import json
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
MODELS = ['sft', 'grpo400', 'random400']
BETAS = [.25, .5, 1.]
POLICY_SHA = 'a6c51596660d338cc9054b9cc0e146478b2d20827ea922f16261d81794774eb3'


def locations(mask):
    return [dict(batch=i // 4 + 1, repeat=i % 4 + 1) for i, keep in enumerate(mask) if not keep]


def interval(vectors, masks):
    """Preserve original complete-data bootstrap; paired deletion otherwise."""
    rng = np.random.default_rng(20261103)
    ix = np.stack([rng.integers(0, 4, size=(10000, 4)) + 4*b for b in range(3)], axis=1)
    if all(mask.all() for mask in masks):
        diff = np.mean(vectors, axis=0)
        draws = diff[ix].mean(axis=(1, 2))
    else:
        # Shared uniforms preserve corresponding Monte Carlo resampling across models.
        uniforms = np.random.default_rng(20261103).random((3, 10000, 4))
        sums = np.zeros(10000); count = 0
        for values, mask in zip(vectors, masks):
            for batch in range(3):
                indices = np.arange(4*batch, 4*batch+4)[mask[4*batch:4*batch+4]]
                n = len(indices)
                if not n:
                    continue
                sampled = indices[(uniforms[batch, :, :n]*n).astype(int)]
                sums += values[sampled].sum(axis=1); count += n
        if not count:
            return None
        draws = sums/count
    return np.quantile(draws, [.025, .975]).tolist()


def summarize(values):
    mask = np.isfinite(values)
    return dict(mean=float(values[mask].mean()) if mask.any() else None,
                ci95=interval([values], [mask]), n_total=len(values), n_effective=int(mask.sum()),
                excluded=locations(mask))


def evaluate(data, mode):
    vals = {}; table = {}
    for model, rows in data.items():
        vals[model] = {}; table[model] = {}
        for name in rows[0]['estimators']:
            cos = np.array([np.nan if r['estimators'][name]['cosines'][0] is None else r['estimators'][name]['cosines'][0] for r in rows])
            original_missing = ~np.isfinite(cos)
            if mode == 'zero_sensitivity':
                cos = np.nan_to_num(cos, nan=0.)
            vals[model][name] = cos
            mse = np.array([np.nan if r['estimators'][name]['relative_mse'][0] is None else r['estimators'][name]['relative_mse'][0] for r in rows])
            c, m = summarize(cos), summarize(mse)
            table[model][name] = dict(mean_cosine=c['mean'], cosine_ci95=c['ci95'],
                mean_relative_mse=m['mean'], relative_mse_ci95=m['ci95'],
                n_total=12, n_cosine=c['n_effective'], cosine_excluded=c['excluded'],
                original_undefined=locations(~original_missing), n_mse=m['n_effective'], mse_excluded=m['excluded'])
        comparisons = {}
        for beta in BETAS:
            name = f'A+{beta:g}*Bcf'
            for comparator in ['CERT-uniform', 'GRPO4', 'CERT-uct']:
                delta = vals[model][name]-vals[model][comparator]
                comparisons[name+'_minus_'+comparator] = dict(**summarize(delta), primary=comparator=='CERT-uniform')
        table[model]['paired_comparisons'] = comparisons
        table[model]['half_reference_reliability'] = [r['half_reference_cosine'] for r in rows]
    checks = []; candidates = []
    for beta in BETAS:
        name = f'A+{beta:g}*Bcf'
        qualified = []
        for model in MODELS:
            comparisons = table[model]['paired_comparisons']
            means = [comparisons[name+'_minus_'+c]['mean'] for c in ['GRPO4', 'CERT-uct']]
            if all(v is not None and v > 0 for v in means):
                qualified.append(model)
        pairs = []
        for pair in itertools.combinations(qualified, 2):
            vectors = [vals[m][name]-vals[m]['GRPO4'] for m in pair]
            masks = [np.isfinite(v) for v in vectors]
            ci = interval(vectors, masks)
            retained = np.concatenate([v[mask] for v, mask in zip(vectors, masks)])
            delta_mean = (float(np.mean(vectors,axis=0).mean()) if all(mask.all() for mask in masks)
                          else float(retained.mean()) if len(retained) else None)
            pairs.append(dict(models=pair, delta_mean=delta_mean,
                ci95=ci, passed=ci is not None and ci[0] > 0, paired_repeats=len(retained),
                n_by_model={m:int(mask.sum()) for m,mask in zip(pair,masks)},
                excluded_by_model={m:locations(mask) for m,mask in zip(pair,masks)}))
        passed = any(p['passed'] for p in pairs)
        candidate_means = [table[m][name]['mean_cosine'] for m in MODELS]
        selectable = all(v is not None for v in candidate_means)
        checks.append(dict(beta=beta, qualified_models=qualified, pairs=pairs, passed=passed, selection_means_defined=selectable))
        if passed and selectable:
            candidates.append((float(np.mean(candidate_means)), beta))
    selected = sorted(candidates, key=lambda x:(-x[0],x[1]))[0][1] if candidates else None
    return dict(mode=mode, passed=bool(candidates), beta=selected, checks=checks, table=table)


def validate(data):
    assert set(data)==set(MODELS)
    for model, rows in data.items():
        assert len(rows)==12 and [(r['batch'],r['repeat']) for r in rows]==[(b,r) for b in range(1,4) for r in range(1,5)]
        for row in rows:
            for name, metric in row['estimators'].items():
                assert np.isfinite(metric['norm2']) and metric['norm2']>=0
                for key in ['cosines','relative_mse']:
                    for index,value in enumerate(metric[key]):
                        if value is None:
                            assert row['reference_norm2'][index]==0 or (key=='cosines' and metric['norm2']==0), (model,name,key)
                        else:
                            assert np.isfinite(value), (model,name,key)


def main():
    policy_path = ROOT/'artifacts/undefined_cosine_policy_20261104.json'
    assert hashlib.sha256(policy_path.read_bytes()).hexdigest()==POLICY_SHA
    data = {m:[json.loads((ROOT/f'runs/phase1/{m}/b{b}_r{r}/result.json').read_text()) for b in range(1,4) for r in range(1,5)] for m in MODELS}
    validate(data)
    primary = evaluate(data, 'exclude_undefined_paired')
    sensitivity = evaluate(data, 'zero_sensitivity')
    report = dict(**primary, zero_sensitivity=sensitivity,
        primary_reported_comparator='CERT-uniform', separate_benchmark='B3 Random K=2',
        predeclared_gate_comparator='CERT-uct', amendment=json.loads(policy_path.read_text()), amendment_sha256=POLICY_SHA,
        interval_method='10000 bootstrap replicates; fixed model/batch strata; retained paired units; observed-count weights; shared resampling across models; original exact bootstrap when complete',
        inference_scope='Post-observation user amendment after SFT and partial GRPO400, before any Random400 result. Conditional Monte Carlo intervals, not independent confirmatory evidence.',
        tie_rule='Highest defined-cosine mean averaged equally across three models; exact ties smaller beta',
        no_test_or_validation_use=True, sensitivity_used_for_selection=False)
    path=ROOT/'artifacts/phase1_gate.json'; tmp=path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(report,indent=2,allow_nan=False));tmp.replace(path)
    print(json.dumps({k:report[k] for k in ['passed','beta','checks','amendment_sha256']},indent=2))


if __name__=='__main__':main()
