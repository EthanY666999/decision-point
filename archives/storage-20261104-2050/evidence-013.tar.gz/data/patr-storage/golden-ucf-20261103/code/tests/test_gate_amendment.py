"""Synthetic CPU regressions; never uses Random400 experiment outcomes."""
import contextlib,copy,io,json,tempfile
from pathlib import Path

def verify(old_source,new_source):
 ns={'__name__':'gate_test','__file__':'/tmp/scripts/phase1_gate.py'};exec(compile(new_source,'gate.py','exec'),ns)
 names=['GRPO4','CERT-uniform','CERT-uct','A+0.25*Bcf','A+0.5*Bcf','A+1*Bcf','Braw','Bht','Bcf']
 data={m:[dict(batch=b,repeat=r,reference_norm2=[1.]*3,half_reference_cosine=.8,estimators={n:dict(norm2=1.,cosines=[(.8 if n.startswith('A+') else .5)+r*.001]*3,relative_mse=[1.]*3) for n in names}) for b in range(1,4) for r in range(1,5)] for m in ns['MODELS']}
 ns['validate'](data);base=ns['evaluate'](data,'exclude_undefined_paired');zero=ns['evaluate'](data,'zero_sensitivity')
 assert base['checks']==zero['checks'] and base['beta']==zero['beta']
 with tempfile.TemporaryDirectory() as d:
  root=Path(d);(root/'artifacts').mkdir()
  for m,rows in data.items():
   for row in rows:
    p=root/f"runs/phase1/{m}/b{row['batch']}_r{row['repeat']}/result.json";p.parent.mkdir(parents=True);p.write_text(json.dumps(row))
  old={'__file__':str(root/'scripts/phase1_gate.py'),'__name__':'old_gate'};exec(old_source,old)
  with contextlib.redirect_stdout(io.StringIO()):old['main']()
  prior=json.loads((root/'artifacts/phase1_gate.json').read_text())
  assert prior['passed']==base['passed'] and prior['beta']==base['beta']
  for a,b in zip(prior['checks'],base['checks']):
   assert a['qualified_models']==b['qualified_models']
   for x,y in zip(a['pairs'],b['pairs']):assert x['ci95']==y['ci95'] and x['delta_mean']==y['delta_mean']
  for m in ns['MODELS']:
   for n in names:
    for field in ['mean_cosine','cosine_ci95','mean_relative_mse','relative_mse_ci95']:assert prior['table'][m][n][field]==base['table'][m][n][field]
 changed=copy.deepcopy(data)
 for n in ['GRPO4','CERT-uct','CERT-uniform']:
  changed['grpo400'][8]['estimators'][n].update(norm2=0.,cosines=[None]*3)
 ns['validate'](changed);a=ns['evaluate'](changed,'exclude_undefined_paired');z=ns['evaluate'](changed,'zero_sensitivity')
 for comp in ['GRPO4','CERT-uct','CERT-uniform']:
  p=a['table']['grpo400']['paired_comparisons']['A+0.25*Bcf_minus_'+comp]
  assert p['n_effective']==11 and p['excluded']==[dict(batch=3,repeat=1)]
 assert a['checks'][0]['pairs'][0]['paired_repeats']==23
 assert z['table']['grpo400']['GRPO4']['n_cosine']==12
 assert z['table']['grpo400']['GRPO4']['mean_cosine']!=a['table']['grpo400']['GRPO4']['mean_cosine']
 # Missing on the candidate side also excludes its comparator from that pair.
 changed['grpo400'][9]['estimators']['A+0.25*Bcf'].update(norm2=0.,cosines=[None]*3)
 a=ns['evaluate'](changed,'exclude_undefined_paired');assert a['table']['grpo400']['paired_comparisons']['A+0.25*Bcf_minus_GRPO4']['n_effective']==10
 for row in changed['grpo400']:
  for n in ['GRPO4','CERT-uct','CERT-uniform']:row['estimators'][n].update(norm2=0.,cosines=[None]*3)
 a=ns['evaluate'](changed,'exclude_undefined_paired');assert 'grpo400' not in a['checks'][0]['qualified_models']
 assert a['table']['grpo400']['paired_comparisons']['A+0.25*Bcf_minus_GRPO4']['ci95'] is None
 bad=copy.deepcopy(data);bad['sft'][0]['estimators']['GRPO4']['cosines'][0]=float('nan')
 try:ns['validate'](bad)
 except AssertionError:pass
 else:raise AssertionError('NaN accepted')
 print('PASS: complete-data gate/intervals identical; symmetric paired deletion; 23 retained pooled repeats; zero sensitivity separate; empty comparison cannot qualify; NaN rejected')
