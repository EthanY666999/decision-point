"""Disposable single-step variant smoke; no model export or continuation into formal run."""
import argparse,json,math,os,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import patr_core as core
from ucf_collect import make_collect
from ucf_weights import training_weights_ucf
from accept_ucf import component_grad

def main():
 p=argparse.ArgumentParser();p.add_argument('--variant',choices=['ucf','noIS','uniform'],required=True);a=p.parse_args()
 os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']));gate=json.loads((ROOT/'artifacts/phase1_gate.json').read_text());assert gate['passed']
 import torch,train
 from ucf_runtime import configure_builder
 configure_builder(train)
 cfg=json.loads((ROOT/'configs/base.json').read_text());cal=json.loads((ROOT/'artifacts/calibration.json').read_text())
 out=ROOT/'runs/variant_smoke'/a.variant;out.mkdir(parents=True,exist_ok=False)
 cfg.update(ucf_variant=a.variant,ucf_beta=gate['beta'],ucf_c0=cal['c0_uniform' if a.variant=='uniform' else 'c0'],ucf_log_dir=str(out/'ucf_logs'),_step=1)
 data=json.loads((ROOT/'artifacts/data.json').read_text())['train'];tasks=[data[i] for i in np.random.default_rng(np.random.SeedSequence([42,1,1701])).choice(len(data),64,replace=False)]
 actor,ref,engine,tok=train.build_models(cfg,42);train.collect=make_collect(core,train.collect);train.training_weights=training_weights_ucf
 rows,stats,events=train.collect(tasks,engine,tok,cfg,'patr',np.random.default_rng(42))
 components={p:component_grad(actor,ref,rows,cfg,tok,p) for p in ['A','B']}
 opt=torch.optim.AdamW(actor.parameters(),lr=cfg['learning_rate'],betas=(.9,.999),eps=1e-8,weight_decay=0.)
 metrics=train.update(actor,ref,opt,rows,cfg,'patr',tok,np.random.default_rng(np.random.SeedSequence([42,1,1702])),64)
 assert math.isfinite(metrics['grad_norm']) and metrics['max_parameter_change']>0
 core.atomic_json(out/'result.json',dict(passed=True,variant=a.variant,beta=cfg['ucf_beta'],c0=cfg['ucf_c0'],model=cfg['model'],smoke_weights_discarded=True,components=components,metrics=metrics,rollout=stats,events=events))
if __name__=='__main__':main()
