"""Serialized calibration/Phase1 successor. Formal training needs its own preflight."""
import fcntl,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'runs/ucf_queue';Q.mkdir(parents=True,exist_ok=True)
PY='/home/vipuser/patr-reproduction/.venv/bin/python'
def status(s,**kw):
 p=Q/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(dict(status=s,pid=os.getpid(),updated=time.time(),**kw),indent=2));tmp.replace(p)
def gpu():return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
def verify():
 protocol=json.loads((ROOT/'artifacts/frozen.json').read_text());cpu=json.loads((ROOT/'artifacts/cpu_acceptance.json').read_text());assert cpu['passed'] and cpu['source_sha256']==protocol['source_sha256']
 for f,h in protocol['source_sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
 assert shutil.disk_usage(ROOT).free>=16*1024**3

def main():
 with (Q/'scheduler.lock').open('a+') as single:
  fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
  while not (ROOT/'runs/g2_evaluation/report.json').exists():
   p=ROOT/'runs/queue/status.json';v=json.loads(p.read_text()) if p.exists() else {}
   if v.get('status')=='error_evidence_retained':raise RuntimeError('G2 predecessor needs recovery: '+str(v))
   status('waiting_g2_report',predecessor=v);time.sleep(20)
  verify()
  with open('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock','a+') as lease:
   while True:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:status('waiting_shared_gpu_lock');time.sleep(20);continue
    if not gpu():break
    fcntl.flock(lease,fcntl.LOCK_UN);status('waiting_other_gpu_process');time.sleep(20)
   def run(name,argv):
    verify();assert not gpu()
    env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
    with (Q/(name+'.log')).open('a') as log:
     p=subprocess.Popen([PY,'-u',*argv],cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
     status('running',stage=name,child_pid=p.pid);assert p.wait()==0,name
    for _ in range(60):
     if not gpu():break
     time.sleep(2)
   if not (ROOT/'artifacts/gpu_acceptance.json').exists():run('acceptance',['scripts/accept_ucf.py'])
   assert json.loads((ROOT/'artifacts/gpu_acceptance.json').read_text())['passed']
   for model in ['sft','grpo400','random400']:
    p=ROOT/f'runs/phase1/{model}/status.json'
    if not p.exists() or json.loads(p.read_text()).get('status')!='complete':run('phase1_'+model,['scripts/phase1_ucf.py','--model',model])
   run('phase1_gate',['scripts/phase1_gate.py'])
   gate=json.loads((ROOT/'artifacts/phase1_gate.json').read_text())
   status('phase1_passed_training_preflight_pending' if gate['passed'] else 'phase1_failed_no_training',beta=gate['beta'])
if __name__=='__main__':
 try:main()
 except BlockingIOError:raise SystemExit('Existing UCF successor queue already owns scheduler lock')
 except Exception as e:status('error_evidence_retained',error=repr(e));raise
