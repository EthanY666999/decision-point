"""Training entrypoint. CPU, GPU and Phase 1 gates must exist before training."""
import argparse,hashlib,json,os,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--variant',choices=['ucf','noIS','uniform'],required=True);p.add_argument('--beta',type=float,required=True);p.add_argument('--c0',type=float,required=True);a=p.parse_args()
 os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']));assert shutil.disk_usage(ROOT).free>=16*1024**3
 for gate in ['cpu_acceptance','gpu_acceptance','phase1_gate']:
  data=json.loads((ROOT/'artifacts'/f'{gate}.json').read_text());assert data['passed'],gate
 phase=json.loads((ROOT/'artifacts/phase1_gate.json').read_text());assert a.beta==phase['beta']
 calibration=json.loads((ROOT/'artifacts/calibration.json').read_text());assert a.c0==calibration['c0_uniform' if a.variant=='uniform' else 'c0']
 protocol=json.loads((ROOT/'artifacts/frozen.json').read_text())
 for f,h in protocol['source_sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h
 cfg=json.loads((ROOT/'configs/base.json').read_text())
 out=ROOT/'runs/formal'/a.variant/'code';out.mkdir(parents=True,exist_ok=False)
 cfg.update(ucf_variant=a.variant,ucf_beta=a.beta,ucf_c0=a.c0,ucf_log_dir=str(out/'ucf_logs'),eval_every=25,steps=400)
 for f in ['train.py','patr_core.py']:shutil.copy2(ROOT/f,out/f);assert (out/f).read_bytes()==(ROOT/f).read_bytes()
 for f in ['artifacts','vendor']:(out/f).symlink_to(ROOT/f,target_is_directory=True)
 (out/'config.json').write_text(json.dumps(cfg,indent=2))
 import patr_core,train
 from ucf_runtime import configure_builder
 configure_builder(train)
 from ucf_collect import make_collect
 from ucf_weights import training_weights_ucf
 patr_core.ROOT=out;train.ROOT=out
 train.collect=make_collect(patr_core,train.collect);train.training_weights=training_weights_ucf
 sys.path.insert(0,str(ROOT/'scripts'))
 from accept_ucf import component_grad
 original_update=train.update
 def update(actor,ref,optimizer,branches,cfg,method,tokenizer,rng,n_tasks):
  diagnostics={part:component_grad(actor,ref,branches,cfg,tokenizer,part) for part in ['A','B']}
  result=original_update(actor,ref,optimizer,branches,cfg,method,tokenizer,rng,n_tasks)
  result['ucf_preupdate_fullbatch_components']=diagnostics
  return result
 train.update=update
 original_evaluate=train.evaluate
 def evaluate(engine,tokenizer,cfg,tasks,path,seed,split):
  result=original_evaluate(engine,tokenizer,cfg,tasks,path,seed,split)
  if split=='test':
   base=Path('/home/vipuser/golden-sft-patr-20261031/results/supplemental500')
   protocol=json.loads((base/'protocol.json').read_text());raw=(base/'tasks.json').read_bytes()
   assert hashlib.sha256(raw).hexdigest()==protocol['task_file_sha256']
   supplemental=json.loads(raw);dest=Path(path).parent/'supplemental500';dest.mkdir(exist_ok=True)
   for i in range(5):original_evaluate(engine,tokenizer,cfg,supplemental[i*100:(i+1)*100],dest/f'batch{i+1}.json',protocol['evaluation_seed'],'supplemental500')
  return result
 train.evaluate=evaluate
 sys.argv=['train.py','--method','patr','--config','config.json'];train.main()
if __name__=='__main__':main()
