"""Run disposable variant acceptance only, holding the shared GPU lease."""
import fcntl,gzip,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
Q=ROOT/'runs/phase2_preflight';Q.mkdir(parents=True,exist_ok=True)
PY='/home/vipuser/patr-reproduction/.venv/bin/python'
def state(status,**kw):
 p=Q/'status.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(dict(status=status,pid=os.getpid(),updated=time.time(),**kw),indent=2));t.replace(p)
def gpu():return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
def main():
 with (Q/'scheduler.lock').open('a+') as single:
  fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
  with Path('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock').open('a+') as lease:
   while True:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:state('waiting_gpu_lock');time.sleep(20);continue
    if not gpu():break
    fcntl.flock(lease,fcntl.LOCK_UN);state('waiting_gpu_process');time.sleep(20)
   assert json.loads((ROOT/'artifacts/phase1_gate.json').read_text())['passed']
   for variant in ['ucf','noIS','uniform']:
    out=ROOT/'runs/variant_smoke'/variant
    assert not out.exists(),str(out)
    env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
    with (Q/(variant+'.log')).open('x') as log:
     child=subprocess.Popen([PY,'-u','scripts/smoke_variant.py','--variant',variant],cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
     state('running',variant=variant,child_pid=child.pid);assert child.wait()==0,variant
    result=json.loads((out/'result.json').read_text());assert result['passed'] and result['smoke_weights_discarded']
    with gzip.open(out/'ucf_logs/raw_leaves_0001.jsonl.gz','rt') as f:rows=[json.loads(x) for x in f]
    assert sum(x['kind']=='initial' for x in rows)==256
    assert sum(x['kind']=='counterfactual' for x in rows)==result['rollout']['cf_cost']['cf_count']
    assert all(len(x['ids'])==len(x['mask'])==len(x['old_logprobs']) for x in rows)
    ctrl=json.loads((out/'ucf_logs/controller_0001.json').read_text());assert ctrl['last_step']==1 and len(ctrl['history'])==1
    assert set(result['components'])=={'A','B'}
    for _ in range(60):
     if not gpu():break
     time.sleep(2)
    assert not gpu()
   state('complete_all_variant_smokes',formal_started=False)
if __name__=='__main__':
 try:main()
 except Exception as e:state('error_evidence_retained',error=repr(e));raise
