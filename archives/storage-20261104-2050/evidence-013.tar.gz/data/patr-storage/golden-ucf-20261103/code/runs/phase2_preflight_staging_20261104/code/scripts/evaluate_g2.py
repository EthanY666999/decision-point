"""Report-only G2 evaluation, preserving the frozen B3 decoding and UID seeds."""
import argparse,hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
OLD=Path('/home/vipuser/golden-cert-20261102-r1/code')
BASE=Path('/home/vipuser/golden-sft-patr-20261031/results/supplemental500')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['uct','uniform'],required=True);a=p.parse_args()
 os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']))
 from train import build_models,evaluate
 from patr_core import atomic_json
 model=OLD/f'runs/g2/{a.arm}/code/runs/formal/patr_seed42/final_model'
 archived=json.loads((model/'model.safetensors.ARCHIVED.json').read_text());assert sha(model/'model.safetensors')==archived['sha256']
 for f in ['train.py','patr_core.py']:assert (ROOT/f).read_bytes()==(OLD/f).read_bytes()
 protocol=json.loads((BASE/'protocol.json').read_text());assert sha(BASE/'tasks.json')==protocol['task_file_sha256']
 tasks=json.loads((BASE/'tasks.json').read_text());main_tasks=json.loads((ROOT/'artifacts/data.json').read_text())['test']
 cfg=dict(protocol['evaluation_config'],model=str(model))
 assert [cfg[k] for k in ['eval_samples','eval_temperature','eval_top_p','eval_top_k']]==[4,.7,.8,20]
 out=ROOT/'runs/g2_evaluation'/a.arm;out.mkdir(parents=True,exist_ok=True)
 atomic_json(out/'identity.json',dict(model_sha256=archived['sha256'],config=cfg,protocol=protocol,main_tasks_sha256=sha(ROOT/'artifacts/data.json'),report_only=True))
 actor,ref,engine,tok=build_models(cfg,42)
 os.environ['PATR_PROGRESS_PATH']=str(out/'progress.json')
 for name,ts in [('main100',main_tasks)]+[(f'batch{i+1}',tasks[i*100:(i+1)*100]) for i in range(5)]:
  dest=out/(name+'.json')
  if dest.exists() and dest.with_suffix('.jsonl').exists():
   rows=[json.loads(s) for s in dest.with_suffix('.jsonl').read_text().splitlines()]
   if len(rows)==len(ts)*4:continue
   raise RuntimeError('Incomplete evidence; manual repair required: '+str(dest))
  atomic_json(out/'status.json',dict(status='running',stage=name,updated=time.time()))
  evaluate(engine,tok,cfg,ts,dest,protocol['evaluation_seed'],name)
 atomic_json(out/'status.json',dict(status='complete',updated=time.time(),report_only=True))
if __name__=='__main__':main()
