"""Primary same-framework comparison; Random K=2 stays a separate benchmark."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from analyze_g2 import read,paired,summary

def main():
 paths={'CERT-Uniform':ROOT/'runs/g2_evaluation/uniform','CERT-UCT':ROOT/'runs/g2_evaluation/uct',
 'Random-K2-seed42':Path('/home/vipuser/golden-next-20261031/b3/code/runs/supplemental500/tree_random'),
 'PaTR-K2':Path('/home/vipuser/golden-next-20261031/b3/code/runs/supplemental500/patr'),
 'GRPO4':Path('/home/vipuser/golden-controls-20261031/code/runs/audit/supplemental500/grpo')}
 arms={}
 for a in ['ucf','noIS','uniform']:
  p=ROOT/f'runs/formal/{a}/code/runs/formal/patr_seed42';s=p/'status.json'
  if s.exists() and json.loads(s.read_text()).get('status')=='complete':paths['UCF-'+a]=p/'supplemental500';arms[a]=p
 assert 'ucf' in arms,'UCF main has not completed'
 random43=Path('/data/patr-storage/golden-b3-k2-seed43-20261104/code')
 s=random43/'runs/queue/status.json'
 if s.exists() and json.loads(s.read_text()).get('status')=='complete_seed43_stability_report':paths['Random-K2-seed43']=random43/'runs/supplemental500'
 groups={name:read([p/f'batch{i}.jsonl' for i in range(1,6)]) for name,p in paths.items()}
 uids=sorted(groups['UCF-ucf']);assert len(uids)==500 and all(set(g)==set(uids) for g in groups.values())
 prior=json.loads((ROOT/'runs/g2_evaluation/report.json').read_text());geometry=prior['geometry']
 excluded=set(json.loads(Path('/home/vipuser/golden-controls-20261031/code/runs/audit/overlap_report.json').read_text())['excluded_uids'])
 strata={'all500':uids,'filtered409':sorted(set(uids)-excluded)}
 assert len(strata['filtered409'])==409,'Fixed overlap sensitivity cohort changed'
 for name,low,high in [('length_le3',0,3),('length_4_5',4,5),('length_6_7',6,7),('length_8_10',8,10)]:strata[name]=[u for u in uids if geometry[u]['shortest_path'] is not None and low<=geometry[u]['shortest_path']<=high]
 length_covered=set().union(*(set(v) for k,v in strata.items() if k.startswith('length_')))
 strata['length_other']=sorted(set(uids)-length_covered)
 for flag in [False,True]:strata['detour_'+str(flag).lower()]=[u for u in uids if geometry[u]['detour']==flag]
 result=dict(primary_comparator='CERT-Uniform',benchmarks=['Random-K2-seed42','Random-K2-seed43'],fifth_evidence_withdrawn=True,completed_ucf_arms=list(arms),no_test_selection=True,limitations=['One training seed per UCF arm; paired intervals concern test tasks, not training seeds','Random K=2 seed42/43 comparison is a descriptive two-seed stability check'],strata={})
 for split,us in strata.items():
  comparisons={}
  if us:
   for a in arms:
    name='UCF-'+a
    for b in ['CERT-Uniform','CERT-UCT','Random-K2-seed42','Random-K2-seed43','PaTR-K2','GRPO4']:
     if b in groups:comparisons[name+'_minus_'+b]=dict(**paired(groups[name],groups[b],us),role='primary' if b=='CERT-Uniform' else 'benchmark' if b.startswith('Random-') else 'secondary')
   for a in ['noIS','uniform']:
    if a in arms:comparisons['UCF-ucf_minus_UCF-'+a]=dict(**paired(groups['UCF-ucf'],groups['UCF-'+a],us),role='ablation')
  result['strata'][split]=dict(n_tasks=len(us),models={name:summary(g,us) for name,g in groups.items()} if us else {},comparisons=comparisons)
 result['main100']={a:summary(read([p/'final_test.jsonl']),sorted(read([p/'final_test.jsonl']))) for a,p in arms.items()}
 dest=ROOT/'runs/final_comparison.json';dest.write_text(json.dumps(result,indent=2));print(dest)
if __name__=='__main__':main()
