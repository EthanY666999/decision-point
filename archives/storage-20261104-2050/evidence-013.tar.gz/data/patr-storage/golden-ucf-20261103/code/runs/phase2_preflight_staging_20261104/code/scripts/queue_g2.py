"""One GPU task at a time, with the existing shared supervisor lock."""
import fcntl,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'runs/queue';Q.mkdir(parents=True,exist_ok=True)
PY='/home/vipuser/patr-reproduction/.venv/bin/python'
def status(s,**kw):
 p=Q/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(dict(status=s,pid=os.getpid(),updated=time.time(),**kw),indent=2));tmp.replace(p)
def gpu():return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
def main():
 with (Q/'scheduler.lock').open('a+') as single:
  fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
  while not (ROOT/'artifacts/restore_receipt.json').exists():status('waiting_verified_restoration');time.sleep(20)
  receipts=json.loads((ROOT/'artifacts/restore_receipt.json').read_text());assert len(receipts)==4 and all(r['verified'] for r in receipts)
  with open('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock','a+') as lease:
   while True:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:status('waiting_shared_gpu_lock');time.sleep(20);continue
    if not gpu():break
    fcntl.flock(lease,fcntl.LOCK_UN);status('waiting_other_gpu_process');time.sleep(20)
   env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
   for arm in ['uct','uniform']:
    assert shutil.disk_usage(ROOT).free>=16*1024**3
    assert not gpu(),'GPU occupied; preserve evidence without interrupting it'
    with (Q/(arm+'.log')).open('a') as log:
     child=subprocess.Popen([PY,'-u',str(ROOT/'scripts/evaluate_g2.py'),'--arm',arm],cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
     status('running_g2_evaluation',arm=arm,child_pid=child.pid)
     assert child.wait()==0,arm
    for _ in range(60):
     if not gpu():break
     time.sleep(2)
   subprocess.run([PY,str(ROOT/'scripts/analyze_g2.py')],cwd=ROOT,check=True)
  status('g2_report_complete_ucf_cpu_gate_pending')
if __name__=='__main__':
 try:main()
 except BlockingIOError:raise SystemExit('Existing queue owns scheduler lock')
 except Exception as e:status('error_evidence_retained',error=repr(e));raise
