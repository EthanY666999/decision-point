"""Fixed report-only task-paired bootstrap, including geometry strata."""
import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import patr_core as core
B3=Path('/home/vipuser/golden-next-20261031/b3/code/runs/supplemental500')
CONTROL=Path('/home/vipuser/golden-controls-20261031/code')
def read(paths):
 rows=[json.loads(line) for p in paths for line in p.open()]
 groups={}
 for r in rows:groups.setdefault(r['task']['uid'],[]).append(r)
 assert all(len(rs)==4 for rs in groups.values())
 return groups

def paired(a,b,uids):
 assert uids and all(u in a and u in b for u in uids)
 ds=np.array([sum(r['reward']>0 for r in a[u])/4-sum(r['reward']>0 for r in b[u])/4 for u in uids])
 rng=np.random.default_rng(20261103);boot=[]
 for _ in range(100):boot.extend(ds[rng.integers(len(ds),size=(100,len(ds)))].mean(1))
 return dict(n_tasks=len(ds),delta_pp=float(ds.mean()*100),ci95_pp=(np.quantile(boot,[.025,.975])*100).tolist(),replicates=10000)
def summary(g,uids):return dict(n_tasks=len(uids),n_trajectories=4*len(uids),success_rate_pct=100*np.mean([sum(r['reward']>0 for r in g[u])/4 for u in uids]),pass_at_4_pct=100*np.mean([any(r['reward']>0 for r in g[u]) for u in uids]))
def main():
 cfg=json.loads((Path('/home/vipuser/golden-cert-20261102-r1/code/configs/cert_g2_uct.json')).read_text())
 groups={a:read([ROOT/f'runs/g2_evaluation/{a}/batch{i}.jsonl' for i in range(1,6)]) for a in ['uct','uniform']}
 groups.update({label:read([path/f'batch{i}.jsonl' for i in range(1,6)]) for label,path in {'b3_patr':B3/'patr','b3_random':B3/'tree_random','grpo4':CONTROL/'runs/audit/supplemental500/grpo'}.items()})
 uids=sorted(groups['uct']);assert len(uids)==500 and all(set(g)==set(uids) for g in groups.values())
 excluded=set(json.loads((CONTROL/'runs/audit/overlap_report.json').read_text())['excluded_uids']);filtered=[u for u in uids if u not in excluded];assert len(filtered)==409
 strata={'all500':uids,'filtered409':filtered,'length_le3':[],'length_4_5':[],'length_6_7':[],'length_8_10':[],'length_other':[],'detour_yes':[],'detour_no':[]};geometry={}
 for u in uids:
  env=core.make_env(groups['uct'][u][0]['task'],cfg);d=core.distance(env);start=divmod(int(env.s),env.ncol);goal=np.argwhere(env.desc==b'G')[0];manhattan=int(abs(start[0]-goal[0])+abs(start[1]-goal[1]));detour=d is not None and d>manhattan
  k='length_le3' if d is not None and d<=3 else 'length_4_5' if d is not None and d<=5 else 'length_6_7' if d is not None and d<=7 else 'length_8_10' if d is not None and d<=10 else 'length_other'
  strata[k].append(u);strata['detour_yes' if detour else 'detour_no'].append(u);geometry[u]=dict(shortest_path=d,manhattan=manhattan,detour=detour)
 report=dict(report_only=True,no_selection=True,detour_definition='BFS safe shortest path > Manhattan distance between actual S and G',limitations=['Single training seed; intervals do not measure training-seed uncertainty','filtered409 is fixed post-hoc overlap sensitivity; no replacement of all500'],geometry=geometry,strata={})
 for name,us in strata.items():
  report['strata'][name]=dict(n_tasks=len(us),models={a:summary(g,us) for a,g in groups.items()} if us else {},comparisons={a+'_minus_'+b:paired(groups[a],groups[b],us) for a in ['uct','uniform'] for b in ['b3_patr','b3_random','grpo4']} if us else {})
 for a in ['uct','uniform']:
  g=read([ROOT/f'runs/g2_evaluation/{a}/main100.jsonl']);assert len(g)==100
  report.setdefault('main100',{})[a]=summary(g,sorted(g))
 core.atomic_json(ROOT/'runs/g2_evaluation/report.json',report)
 print(json.dumps({s:v['models'] for s,v in report['strata'].items() if s in ['all500','filtered409']},indent=2))
if __name__=='__main__':main()
