"""Formal UCF arms, with an unlocked seed43 benchmark slot after the main arm."""
import fcntl,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];Q=ROOT/'runs/phase2_queue';Q.mkdir(parents=True,exist_ok=True)
PY='/home/vipuser/patr-reproduction/.venv/bin/python'
BENCH=Path('/data/patr-storage/golden-b3-k2-seed43-20261104/code/runs/queue/status.json')
LOCK=Path('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock')
def read(p):return json.loads(p.read_text()) if p.exists() else {}
def status(s,**kw):
 p=Q/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(dict(status=s,pid=os.getpid(),updated=time.time(),**kw),indent=2));tmp.replace(p)
def gpu():return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
def verify():
 f=read(ROOT/'artifacts/frozen.json');c=read(ROOT/'artifacts/cpu_acceptance.json')
 assert c['passed'] and c['source_sha256']==f['source_sha256']
 for n,h in f['source_sha256'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 for name in ['gpu_acceptance','phase1_gate']:assert read(ROOT/f'artifacts/{name}.json')['passed'],name
 assert shutil.disk_usage(ROOT).free>=16*1024**3

def arm(variant,beta,c0):
 formal=ROOT/f'runs/formal/{variant}/code/runs/formal/patr_seed42';smoke=ROOT/f'runs/variant_smoke/{variant}'
 if read(formal/'status.json').get('status')=='complete':return
 with LOCK.open('a+') as lease:
  while True:
   try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:status('waiting_gpu_lock',variant=variant);time.sleep(20);continue
   if not gpu():break
   fcntl.flock(lease,fcntl.LOCK_UN);status('waiting_gpu_process',variant=variant);time.sleep(20)
  def run(stage,argv):
   verify();assert not gpu()
   env=dict(os.environ,NEXT_GPU_LEASE_FD=str(lease.fileno()),CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1')
   with (Q/(variant+'_'+stage+'.log')).open('a') as log:
    child=subprocess.Popen([PY,'-u',*argv],cwd=ROOT,env=env,pass_fds=(lease.fileno(),),stdout=log,stderr=subprocess.STDOUT)
    status('running',variant=variant,stage=stage,child_pid=child.pid);assert child.wait()==0,(variant,stage)
   for _ in range(60):
    if not gpu():break
    time.sleep(2)
   assert not gpu(),'GPU child survived completed stage'
  result=read(smoke/'result.json')
  if not result.get('passed'):
   if smoke.exists():smoke.rename(smoke.with_name(variant+'_incomplete_'+str(time.time_ns())))
   run('smoke',['scripts/smoke_variant.py','--variant',variant]);result=read(smoke/'result.json')
  assert result['passed'] and result['variant']==variant
  assert result['beta']==beta and result['c0']==c0 and result['smoke_weights_discarded']
  command=['run_ucf.py','--variant',variant,'--beta',str(beta),'--c0',str(c0)]
  if (formal/'checkpoint.pt').exists():command+=['--resume']
  run('formal',command)
  assert read(formal/'status.json').get('status')=='complete','Incomplete formal arm; preserve checkpoint for recovery'
 subprocess.run([PY,'scripts/analyze_ucf_final.py'],cwd=ROOT,check=True)

def main():
 with (Q/'scheduler.lock').open('a+') as single:
  fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB);verify()
  g=read(ROOT/'artifacts/phase1_gate.json');cal=read(ROOT/'artifacts/calibration.json')
  arm('ucf',g['beta'],cal['c0'])
  # No GPU lock is held while the separately scheduled B3 seed43 arm runs.
  while read(BENCH).get('status')!='complete_seed43_stability_report':
   s=read(BENCH)
   if s.get('status') in ['error_evidence_retained','not_eligible_ucf_main_not_started_phase1_failed']:
    raise RuntimeError('Seed43 slot requires recovery: '+str(s))
   status('waiting_seed43_benchmark',benchmark=s);time.sleep(30)
  subprocess.run([PY,'scripts/analyze_ucf_final.py'],cwd=ROOT,check=True)
  for variant in ['noIS','uniform']:arm(variant,g['beta'],cal['c0_uniform'] if variant=='uniform' else cal['c0'])
  status('complete_all_arms_and_seed43_report')
if __name__=='__main__':
 try:main()
 except BlockingIOError:raise SystemExit('Existing phase2 queue owns lock')
 except Exception as e:status('error_evidence_retained',error=repr(e));raise
