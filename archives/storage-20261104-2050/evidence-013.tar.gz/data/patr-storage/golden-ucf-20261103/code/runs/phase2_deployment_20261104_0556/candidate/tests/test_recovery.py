import json,tempfile,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ucf_recovery import reconcile_checkpoint
class RecoveryTest(unittest.TestCase):
 def test_reconcile_preserves_future_and_restores_state(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);logs=root/'ucf_logs';logs.mkdir();formal=root/'runs/formal/patr_seed42';formal.mkdir(parents=True)
   snap=dict(c=.4,history=[2,2],last_step=2)
   (logs/'controller_0002.json').write_text(json.dumps(snap));(logs/'controller_0003.json').write_text(json.dumps(dict(c=.5,history=[2,2,0],last_step=3)));(logs/'controller.json').write_text((logs/'controller_0003.json').read_text())
   (logs/'select_0003.jsonl').write_text('raw future selection\n');(formal/'rollouts_0003.jsonl.gz').write_bytes(b'future rollout bytes')
   for name in ['train_metrics.jsonl','branch_events.jsonl']:(formal/name).write_text(''.join(json.dumps({'step':s})+'\n' for s in [1,2,3]))
   result=reconcile_checkpoint(root,2)
   self.assertEqual(json.loads((logs/'controller.json').read_text()),snap);self.assertFalse((logs/'select_0003.jsonl').exists())
   self.assertEqual(len(result['preserved']),5)
   self.assertTrue(all(Path(r['archive']).is_file() for r in result['preserved']))
   self.assertEqual([json.loads(r)['step'] for r in (formal/'train_metrics.jsonl').read_text().splitlines()],[1,2])
 def test_bad_snapshot_makes_no_changes(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);logs=root/'ucf_logs';logs.mkdir();p=logs/'controller_0002.json';p.write_text(json.dumps(dict(c=.4,history=[2],last_step=2)))
   with self.assertRaises(AssertionError):reconcile_checkpoint(root,2)
   self.assertFalse((root/'recovery').exists())
if __name__=='__main__':unittest.main()
