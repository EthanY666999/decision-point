import importlib.util,json,tempfile,unittest
from pathlib import Path
import queue_tail as q
import report as r

class Gates(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def complete(self):
        q.atomic(self.root/'runs/multiseed_queue/status.json',{'status':'complete_ucf_seeds42_43_and_reports_seed44_cancelled'})
        q.atomic(self.root/'runs/multiseed_queue/report.json',dict(complete_requested_seeds=True,cancelled_seeds=[44],seed43_vs_seed42={'all500':1},available_seeds=[42,43],paired_seed43_vs_random43={'all500':1},seed_mean_std={'main100':1}))
        for n in ['training_curves.png','training_curves.svg',*[f'curves_seed{s}.json' for s in [42,43]]]:
            (self.root/'runs/multiseed_queue'/n).write_text('evidence')
        for seed in [42,43]:
            p=self.root/f'runs/ucf_seed_replicates/seed{seed}/code/runs/formal/patr_seed{seed}'
            q.atomic(p/'status.json',dict(status='complete',step=400))
            for n in ['final_test.json','final_test.jsonl',*[f'supplemental500/batch{i}.{ext}' for i in range(1,6) for ext in ['json','jsonl']]]:
                (p/n).parent.mkdir(exist_ok=True,parents=True);(p/n).write_text('data')
        q.atomic(self.root/'runs/phase2_queue/status.json',dict(status='complete_all_arms_and_seed43_report'))
    def test_empty_blocks(self):self.assertFalse(q.prerequisites(self.root))
    def test_running_seed43_blocks(self):
        self.complete();q.atomic(self.root/'runs/multiseed_queue/status.json',dict(status='running',seed=43));self.assertFalse(q.prerequisites(self.root))
    def test_report_missing_blocks(self):
        self.complete();(self.root/'runs/multiseed_queue/report.json').unlink();self.assertFalse(q.prerequisites(self.root))
    def test_curves_missing_blocks(self):
        self.complete();(self.root/'runs/multiseed_queue/training_curves.svg').unlink();self.assertFalse(q.prerequisites(self.root))
    def test_raw_missing_blocks(self):
        self.complete();next(self.root.glob('runs/ucf_seed_replicates/seed43/**/batch5.jsonl')).unlink();self.assertFalse(q.prerequisites(self.root))
    def test_399_blocks(self):
        self.complete();p=self.root/'runs/ucf_seed_replicates/seed43/code/runs/formal/patr_seed43/status.json';q.atomic(p,dict(status='complete',step=399));self.assertFalse(q.prerequisites(self.root))
    def test_complete_allows(self):self.complete();self.assertTrue(q.prerequisites(self.root))
    def test_missing_seed43_comparison_blocks(self):
        self.complete();p=self.root/'runs/multiseed_queue/report.json';d=q.read(p);d['seed43_vs_seed42']=None;q.atomic(p,d);self.assertFalse(q.prerequisites(self.root))
    def test_old_three_seed_terminal_blocks(self):
        self.complete();q.atomic(self.root/'runs/multiseed_queue/status.json',dict(status='complete_ucf_seeds42_43_44_and_reports'));self.assertFalse(q.prerequisites(self.root))
    def test_no_seed44_artifacts_required(self):
        self.complete();self.assertFalse((self.root/'runs/ucf_seed_replicates/seed44').exists());self.assertTrue(q.prerequisites(self.root))
    def test_config_diff(self):self.assertEqual(q.diff({'seed':42,'model':'sft'},{'seed':42,'model':'base'}),{'model':['sft','base']})
    def test_summary_preserves_four(self):
        rows={'a':[dict(reward=x) for x in [1,0,0,0]],'b':[dict(reward=0) for _ in range(4)]}
        s=r.summarize(rows,rows);self.assertEqual(s['success_rate_pct'],12.5);self.assertEqual(s['pass_at_4_pct'],50)
    def test_nonfinite_detection(self):self.assertFalse(r.finite({'grad':[float('nan')]}))
    def test_cleanup_requires_publication(self):
        old=q.Q;q.Q=self.root
        try:
            with self.assertRaises(AssertionError):q.finalize()
        finally:q.Q=old

if __name__=='__main__':unittest.main()
