"""Separate report-only map8 evaluation; training environment is never patched."""
import os,sys
from queue_tail import ROOT,Q,FORMAL,read,atomic,sha
sys.path.insert(0,str(ROOT))

def main():
    os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']))
    import train,patr_core as core
    import numpy as np
    cfg=dict(read(FORMAL/'config.json'),model=str(FORMAL/'final_model'))
    tasks=read(ROOT/'artifacts/data.json')['test'];assert len(tasks)==100
    assert cfg['max_turns']==10
    assert [cfg[k] for k in ['eval_samples','eval_temperature','eval_top_p','eval_top_k']]==[4,.7,.8,20]
    out=Q/'map8';out.mkdir(parents=True,exist_ok=False)
    def env8(task,cfg):
        e=core.FrozenLakeEnv(size=task['size'],p=task['p'],seed=task['seed'],is_slippery=cfg['is_slippery'],max_steps=8)
        e.reset();return e
    maps=[]
    for t in tasks:
        a=core.make_env(t,cfg);b=env8(t,cfg)
        maps.append(dict(uid=t['uid'],changed=not np.array_equal(a.desc,b.desc),map10=[''.join(x.decode() for x in r) for r in a.desc],map8=[''.join(x.decode() for x in r) for r in b.desc]))
    old=read('/home/vipuser/golden-sft-patr-20261031/results/main100/analysis/map_comparison.json')
    expected={m['uid']:m['map8'] for m in old['maps']}
    assert len(expected)==100 and all(m['map8']==expected[m['uid']] for m in maps)
    atomic(out/'maps.json',dict(maps=maps,changed=sum(m['changed'] for m in maps),map_generation_max_steps=8,interaction_horizon=10,old_map8_geometry_verified=True))
    core.make_env=env8
    actor,ref,engine,tok=train.build_models(cfg,42)
    os.environ['PATR_PROGRESS_PATH']=str(out/'progress.json')
    train.evaluate(engine,tok,cfg,tasks,out/'result.json',200042,'test_map_generation_max_steps8_interaction_horizon10')
    atomic(out/'identity.json',dict(complete=True,model=cfg['model'],model_sha256=sha(FORMAL/'final_model/model.safetensors'),evaluation_seed=200042,config=cfg,report_only=True,limitation='Only map-generation max_steps=8 aligns with the cited upstream recipe; not a verified full reproduction of the paper.'))

if __name__=='__main__':main()
