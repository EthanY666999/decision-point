"""Train-only recalibration and one disposable update using unchanged UCF helpers."""
import argparse,gzip,json,math,os,sys,time
from collections import Counter
from pathlib import Path
from queue_tail import ROOT,Q,read,atomic,sha
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))

def describe(xs):
    import numpy as np
    a=np.asarray(xs,dtype=float)
    return dict(n=len(xs),values=list(xs),mean=float(a.mean()) if len(a) else None,quantile_probabilities=[0,.25,.5,.75,.95,1],quantiles=np.quantile(a,[0,.25,.5,.75,.95,1]).tolist() if len(a) else [])

def main():
    import numpy as np
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['calibration','smoke'],required=True);stage=ap.parse_args().stage
    os.fstat(int(os.environ['NEXT_GPU_LEASE_FD']))
    import train,patr_core as core,torch
    from ucf_runtime import configure_builder
    from cert_select import stable_seed
    from ucf_collect import initial_ucf,make_collect
    from ucf_select import feature,calibrate,RHO_MIN
    from ucf_weights import training_weights_ucf
    from accept_ucf import component_grad
    configure_builder(train)
    cfg=dict(read(ROOT/'configs/base.json'),ucf_variant='ucf',ucf_beta=.25)
    out=Q/f'{stage}_attempts'/str(time.time_ns());out.mkdir(parents=True)
    data=read(ROOT/'artifacts/data.json')['train']
    batches=[[data[i] for i in np.random.default_rng(np.random.SeedSequence([42,b+1,1701])).choice(len(data),64,replace=False)] for b in range(3)]
    atomic(out/'tasks.json',dict(train_only=True,batches=batches,seeds=[[42,b+1,1701] for b in range(3)]))
    os.environ['PATR_PROGRESS_PATH']=str(out/'progress.json')
    actor,ref,engine,tok=train.build_models(cfg,42)
    if stage=='calibration':
        weights=[];records=[]
        for bi,tasks in enumerate(batches):
            seed=stable_seed(42,'ucf-calibration',bi)
            first,candidates,icost,pcost=initial_ucf(core,tasks,engine,tok,cfg,seed)
            ws=[[feature(n,first)[0] for n in candidates[i]] for i in range(64)];weights.extend(ws)
            with gzip.open(out/f'initial_batch{bi+1}.jsonl.gz','xt') as f:
                for b in first:f.write(json.dumps(dict(task=tasks[b.task_id],lineage=b.lineage,ids=b.ids,mask=b.mask,old_logprobs=b.old_logprobs,trace=b.trace,actions=b.actions,reward=b.reward,terminal=b.terminal))+'\n')
            row=dict(batch=bi+1,seed=seed,weights=ws,initial_cost=icost,probe_cost=pcost)
            atomic(out/f'calibration_{bi+1}.json',row);records.append(row)
        c0=calibrate(weights)
        expected=sum(sum(min(1,max(RHO_MIN,c0*w)) for w in ws) for ws in weights)/len(weights)
        assert abs(expected-2)<1e-10
        atomic(ROOT/'artifacts/calibration.json',dict(c0=c0,mean_expected_forks=expected,n_tasks=192,nosft_train_only_complete=True,train_only=True,beta=.25,beta_reselected=False,method='Frozen ucf_select.calibrate: 80 bisection iterations; rho_min .03; expected forks/task target 2',batches=records,raw_evidence=str(out)))
        return
    cfg.update(ucf_c0=read(ROOT/'artifacts/calibration.json')['c0'],ucf_log_dir=str(out/'ucf_logs'),_step=1)
    train.collect=make_collect(core,train.collect);train.training_weights=training_weights_ucf
    branches,stats,events=train.collect(batches[0],engine,tok,cfg,'patr',np.random.default_rng(42))
    ns=[e for e in events if e.get('kind')=='ucf_fork']
    mismatches=[n for n in ns if n.get('cf_parse_mismatch')]
    initial_invalid=[];cf_raw={}
    with gzip.open(out/'ucf_logs/raw_leaves_0001.jsonl.gz','rt') as f:
        for line in f:
            r=json.loads(line)
            if r['kind']=='initial':initial_invalid.append(bool(r['actions'] and r['actions'][0]==0))
            else:cf_raw[(r['task_id'],r['lineage'])]=r
    mismatch_details=[]
    for n in mismatches:
        raw=cf_raw[(n['task_id'],f"{n['j']}@{n['turn']}.cf")]
        trace=raw['trace'][n['turn']-1];text=trace['response'];action=trace.get('action')
        reason=('generation_or_token_limit_before_action' if action is None else
                'missing_complete_triple_backtick_fence' if text.count('```')<2 else
                'strict_parser_returned_invalid_action' if action==0 else 'parsed_action_differs_from_forced_action_token')
        mismatch_details.append(dict(task_id=n['task_id'],original_lineage=n['j'],turn=n['turn'],forced_token=n['forced_token'],parsed_action=action,response=text,reason=reason))
    report=dict(stage='one_disposable_update',model=cfg['model'],beta=.25,c0=cfg['ucf_c0'],cf_fallback=stats['cf_fallback_fraction'],cf_parse_mismatch=stats['cf_parse_mismatch_fraction'],original_parse_mismatch=stats['parse_mismatch_fraction'],unsampled_mass=describe(stats['unsampled_mass_values']),pi_o=describe(stats['pi_o_values']),first_turn_invalid_fraction=sum(initial_invalid)/len(initial_invalid),cf_mismatch_nodes=mismatches,cf_mismatch_explanation='Forced fence/action tokens are scored by the actor, but the generated suffix can fail the unchanged complete-fence parser or alter its parsed action. Exact original/CF traces and selected nodes are retained for each mismatch; original token-class mismatch is reported separately.',cf_parse_mismatch_above_2pct_nonblocking=stats['cf_parse_mismatch_fraction']>.02,raw_evidence=str(out),rollout=stats,events=events,smoke_weights_discarded=True)
    atomic(out/'sampling_report.json',report)
    report.update(cf_mismatch_details=mismatch_details,cf_mismatch_reason_counts=dict(Counter(x['reason'] for x in mismatch_details)))
    atomic(out/'sampling_report.json',report)
    components={part:component_grad(actor,ref,branches,cfg,tok,part) for part in ['A','B']}
    optimizer=torch.optim.AdamW(actor.parameters(),lr=cfg['learning_rate'],betas=(.9,.999),eps=1e-8,weight_decay=0.)
    metrics=train.update(actor,ref,optimizer,branches,cfg,'patr',tok,np.random.default_rng(np.random.SeedSequence([42,1,1702])),64)
    assert math.isfinite(metrics['grad_norm']) and metrics['max_parameter_change']>0
    assert all(math.isfinite(x) for b in branches for x in b.old_logprobs)
    report.update(components=components,smoke=metrics,passed=True,nosft_smoke_passed=True,scientific_gate='beta fixed by user; mismatch is diagnostic only, not a training veto')
    atomic(out/'result.json',report);atomic(ROOT/'artifacts/gpu_acceptance.json',report)

if __name__=='__main__':main()
