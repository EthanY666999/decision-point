"""Publish this run's bounded evidence only; token via stdin, never saved or printed."""
import json,os,shutil,subprocess,sys
from pathlib import Path
from queue_tail import Q,read,sha,atomic

def main():
    assert read(Q/'report.json')['verified_complete'] and read(Q/'verification.json')['verified']
    src=Q/'publish';manifest=read(src/'publication_manifest.json')
    assert manifest['repository']=='EthanY666999/decision-point'
    rel=manifest['destination'];assert rel=='archives/ucf-nosft-20261106'
    for n,v in manifest['files'].items():
        assert Path(n).name==n and (src/n).stat().st_size==v['bytes']<99_000_000 and sha(src/n)==v['sha256']
    token=sys.stdin.readline().strip();assert token
    env=dict(os.environ,ACL_GITHUB_TOKEN=token,GIT_TERMINAL_PROMPT='0',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='credential.helper',GIT_CONFIG_VALUE_0='!f() { printf "%s\\n" "username=x-access-token" "password=$ACL_GITHUB_TOKEN"; }; f')
    repo=Q/'git-publish';repo.mkdir(exist_ok=True)
    def git(*args,check=True):
        p=subprocess.run(['git','-C',str(repo),*args],env=env,text=True,capture_output=True)
        if check and p.returncode:raise RuntimeError('git operation failed: '+args[0]+'; exit '+str(p.returncode))
        return p
    if not (repo/'.git').exists():
        git('init');git('remote','add','origin','https://github.com/EthanY666999/decision-point.git')
        git('config','user.name','Ethanwww');git('config','user.email','238026754+EthanY666999@users.noreply.github.com')
    dst=repo/rel;dst.mkdir(parents=True,exist_ok=True)
    names=sorted([*manifest['files'],'publication_manifest.json'])
    for n in names:shutil.copy2(src/n,dst/n)
    for _ in range(4):
        git('fetch','--filter=blob:none','--depth=1','origin','main')
        parent=git('rev-parse','FETCH_HEAD').stdout.strip();git('read-tree',parent);git('add','--',rel)
        tree=git('write-tree','--missing-ok').stdout.strip()
        commit=git('commit-tree',tree,'-p',parent,'-m','Archive verified no-SFT UCF seed42 evidence; retain final model').stdout.strip()
        pushed=git('push','origin',commit+':refs/heads/main',check=False)
        if pushed.returncode:continue
        git('fetch','--depth=20','origin','main')
        git('merge-base','--is-ancestor',commit,'FETCH_HEAD')
        # Read every archived blob back from the verified remote commit and hash it.
        import hashlib
        for n in names:
            blob=subprocess.run(['git','-C',str(repo),'show',commit+':'+rel+'/'+n],env=env,capture_output=True,check=True).stdout
            assert hashlib.sha256(blob).hexdigest()==sha(src/n),n
        atomic(Q/'publication_receipt.json',dict(remote_verified=True,commit=commit,parent=parent,repository=manifest['repository'],path=rel,files_verified=len(names),publication_manifest_sha256=sha(src/'publication_manifest.json')))
        print(json.dumps(read(Q/'publication_receipt.json')));return
    raise RuntimeError('Publication failed or concurrent remote changes; checkpoint retained')

if __name__=='__main__':main()
