"""Prepare bounded light evidence archives and a pre-deletion manifest, never delete."""
import gzip,json,os,tarfile,time
from pathlib import Path
from queue_tail import ROOT,Q,HERE,FORMAL,read,atomic,sha

def main():
    assert read(Q/'report.json')['verified_complete'] and read(Q/'verification.json')['verified']
    dst=Q/'publish';dst.mkdir(exist_ok=True)
    cp=FORMAL/'checkpoint.pt';assert cp.is_file()
    final={str(p.relative_to(FORMAL/'final_model')):sha(p) for p in (FORMAL/'final_model').rglob('*') if p.is_file()}
    assert 'model.safetensors' in final
    atomic(dst/'deletion_manifest.json',dict(allowed_scope=str(cp),checkpoint=dict(path=str(cp),bytes=cp.stat().st_size,sha256=sha(cp)),retained_final_model_sha256=final,rule='Delete only this checkpoint after all evaluations verified and this exact manifest published. Preserve final_model and every raw evidence file.'))
    inventory=[];include=[]
    for root in [ROOT,HERE,Q]:
        for base,ds,fs in os.walk(root,followlinks=False):
            ds[:]=[d for d in ds if d not in ['publish','git-publish','vendor','__pycache__','.git'] and not (Path(base)/d).is_symlink()]
            for fn in sorted(fs):
                p=Path(base)/fn
                if p.is_symlink() or fn.endswith(('.lock','.tmp')):continue
                rel=str(p.relative_to(HERE.parent));size=p.stat().st_size
                weight=fn.endswith(('.pt','.safetensors','.bin')) or 'final_model' in p.parts
                rawtrain=fn.startswith(('rollouts_','raw_leaves_','initial_batch'))
                archived=not weight and not rawtrain
                inventory.append(dict(path=str(p),relative_path=rel,bytes=size,sha256=sha(p),archive=archived,server_only_reason='weights retained on server' if weight else ('raw training trajectory retained on server' if rawtrain else None)))
                if archived:include.append(p)
    atomic(dst/'evidence_index.json',dict(created=time.time(),files=inventory,raw_evidence_never_deleted=True))
    # Group small files into <=32 MiB uncompressed archives. Large individual logs
    # are gzip-compressed and split into <=90 MB parts with reassembly metadata.
    groups=[];group=[];total=0;large=[]
    for p in include:
        size=p.stat().st_size
        if size>32*1024**2:large.append(p);continue
        if group and total+size>32*1024**2:groups.append(group);group=[];total=0
        group.append(p);total+=size
    if group:groups.append(group)
    for i,files in enumerate(groups):
        with tarfile.open(dst/f'evidence-{i:03d}.tar.gz','w:gz') as tar:
            for p in files:tar.add(p,arcname=str(p.relative_to(HERE.parent)),recursive=False)
    split=[]
    for i,p in enumerate(large):
        tmp=dst/f'large-{i:03d}.gz.tmp'
        with p.open('rb') as f,gzip.open(tmp,'wb') as z:
            for b in iter(lambda:f.read(1024**2),b''):z.write(b)
        names=[]
        with tmp.open('rb') as f:
            j=0
            while True:
                b=f.read(90_000_000)
                if not b:break
                name=f'large-{i:03d}.gz.part{j:03d}';(dst/name).write_bytes(b);names.append(name);j+=1
        split.append(dict(original=str(p),gzip_parts_in_order=names,original_sha256=sha(p)));tmp.unlink()
    atomic(dst/'reassembly.json',split)
    files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in dst.iterdir() if p.is_file() and p.name!='publication_manifest.json'}
    assert all(v['bytes']<99_000_000 for v in files.values())
    atomic(dst/'publication_manifest.json',dict(repository='EthanY666999/decision-point',destination='archives/ucf-nosft-20261106',files=files,weights_uploaded=False,checkpoint_deletion_requires_verified_publication=True))
    print(json.dumps(dict(files=len(files),directory=str(dst),checkpoint_deleted=False)))

if __name__=='__main__':main()
