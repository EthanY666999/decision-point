"""Raw-count verified no-SFT report; historical results are descriptive only."""
import json,math,statistics
from pathlib import Path
from queue_tail import ROOT,Q,LIVE,FORMAL,HERE,read,atomic,sha,diff

def groups(paths,n):
    result={}
    for p in paths:
        for line in p.open():
            row=json.loads(line);result.setdefault(row['task']['uid'],[]).append(row)
    assert len(result)==n
    assert all(len(v)==4 and len({r['lineage'] for r in v})==4 for v in result.values())
    return result

def summarize(g,uids):
    uids=sorted(uids);n=len(uids);assert n
    success=sum(r['reward']>0 for u in uids for r in g[u]);passed=sum(any(r['reward']>0 for r in g[u]) for u in uids)
    return dict(n_tasks=n,n_trajectories=n*4,successes=success,passed_tasks=passed,success_rate_pct=100*success/(4*n),pass_at_4_pct=100*passed/n)

def check_summary(actual,expected):
    for k in ['n_tasks','n_trajectories','success_rate_pct','pass_at_4_pct']:
        assert abs(actual[k]-expected[k])<1e-9,(k,actual[k],expected[k])

def finite(x):
    if isinstance(x,float):return math.isfinite(x)
    if isinstance(x,dict):return all(finite(v) for v in x.values())
    if isinstance(x,list):return all(finite(v) for v in x)
    return True

def main():
    plan=read(HERE/'protocol.json');assert read(FORMAL/'status.json')['status']=='complete'
    cfg=read(LIVE/'config.json');expected=read(Q/'config_final.json');assert cfg==expected
    assert set(diff(plan['actual_seed42'],cfg))<= {'model','ucf_c0','ucf_log_dir'}
    assert read(Q/'map8/identity.json')['complete']
    main_groups=groups([FORMAL/'final_test.jsonl'],100)
    results={'main100':summarize(main_groups,main_groups)}
    check_summary(results['main100'],read(FORMAL/'final_test.json'))
    g=groups([FORMAL/f'supplemental500/batch{i}.jsonl' for i in range(1,6)],500)
    taskpath=Path(plan['supplemental_tasks']);tasks=read(taskpath);assert {t['uid'] for t in tasks}==set(g)
    byuid={t['uid']:t for t in tasks};assert all(r['task']==byuid[u] for u,rs in g.items() for r in rs)
    for i in range(1,6):
        batch=groups([FORMAL/f'supplemental500/batch{i}.jsonl'],100)
        check_summary(summarize(batch,batch),read(FORMAL/f'supplemental500/batch{i}.json'))
    excluded=set(read(plan['overlap_report'])['excluded_uids']);filtered=set(g)-excluded;assert len(filtered)==409
    results.update(all500=summarize(g,g),filtered409=summarize(g,filtered))
    maps=groups([Q/'map8/result.jsonl'],100);assert set(maps)==set(main_groups)
    results['map8']=summarize(maps,maps);check_summary(results['map8'],read(Q/'map8/result.json'))
    metrics=[json.loads(line) for line in (FORMAL/'train_metrics.jsonl').read_text().splitlines()]
    assert [m['step'] for m in metrics]==list(range(1,401))
    assert all(finite(m) and m['max_parameter_change']>0 for m in metrics)
    vals={int(p.stem.split('_')[-1]):read(p) for p in FORMAL.glob('validation_*.json')};assert set(vals)==set(range(0,401,25))
    ent={}
    for line in (FORMAL/'branch_events.jsonl').open():
        row=json.loads(line);es=[e for e in row['events'] if e.get('kind')=='ucf_fork']
        ent[row['step']]={k:statistics.mean(e[k] for e in es) if es else None for k in ['H_act','H_cons']}
        ent[row['step']]['n_selected']=len(es)
    curve=[]
    for m in metrics:
        assert ent[m['step']]['n_selected']==m['branch_events']
        curve.append({k:m[k] for k in ['step','success_rate','mean_forks','fork_counts','c_step','c_next','counterfactual_flip_rate','invalid_action_fraction','cf_fallback_fraction','cf_parse_mismatch_fraction','pi_o_values','unsampled_mass_values','generated_tokens','input_tokens','rollout_sampled_surprisal','grad_norm','kl','step_seconds']} | dict(selected_node_entropy=ent[m['step']],validation=vals.get(m['step'])))
    definitions=dict(selected_node_entropy='H_act/H_cons from selected nodes only; selection-biased normalized entropies.',rollout_sampled_surprisal='Initial sampled-token negative log-probability MC entropy estimate, not exact full-vocabulary entropy; no retokenization.',invalid_action_fraction='All executed initial/CF actions in the frozen rollout accounting; strict parser unchanged.')
    atomic(Q/'training_curves.json',dict(seed=42,initial_validation=vals[0],definitions=definitions,steps=curve))
    report=dict(verified_complete=True,model=plan['model'],model_sha256=plan['model_sha256'],hardware=read(Q/'hardware.json'),configuration_diff=read(Q/'config_diff.json'),calibration=read(ROOT/'artifacts/calibration.json'),smoke={k:v for k,v in read(ROOT/'artifacts/gpu_acceptance.json').items() if k not in ['events','rollout','cf_mismatch_nodes']},results=results,historical=plan['historical'],paper_values=plan['paper_values'],limitations=plan['limitations'],report_only=True,no_test_selection=True,training=dict(steps=400,all_metrics_finite=True,all_parameter_updates_positive=True,generated_tokens=sum(m['generated_tokens'] for m in metrics),input_tokens=sum(m['input_tokens'] for m in metrics),actor_scoring_input_tokens=sum(m['probe_cost']['input_tokens'] for m in metrics),seconds=sum(m['step_seconds'] for m in metrics)))
    atomic(Q/'report.json',report)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(4,2,figsize=(13,15),constrained_layout=True);x=[r['step'] for r in curve]
    for ax,key,label in [(axs[0,0],'success_rate','Initial sampling success'),(axs[1,0],'mean_forks','Forks per task'),(axs[1,1],'counterfactual_flip_rate','Counterfactual flip rate'),(axs[2,1],'rollout_sampled_surprisal','Initial token entropy MC estimate'),(axs[3,0],'invalid_action_fraction','Invalid action fraction'),(axs[3,1],'c_step','Controller c_step')]:
        ax.plot(x,[r[key] for r in curve]);ax.set_title(label)
    axs[0,1].plot(sorted(vals),[vals[k]['success_rate_pct'] for k in sorted(vals)],label='success')
    axs[0,1].plot(sorted(vals),[vals[k]['pass_at_4_pct'] for k in sorted(vals)],label='pass@4');axs[0,1].legend();axs[0,1].set_title('Fixed validation (%)')
    for k in ['H_act','H_cons']:axs[2,0].plot(x,[r['selected_node_entropy'][k] for r in curve],label=k)
    axs[2,0].legend();axs[2,0].set_title('Selected-node normalized entropy')
    for ax in axs.flat:ax.grid(alpha=.2);ax.set_xlabel('Step')
    fig.savefig(Q/'training_curves.png',dpi=160);fig.savefig(Q/'training_curves.svg');plt.close(fig)
    lines=['# UCF without SFT — seed42','', 'Hardware: A100-SXM4-40GB. 400 steps, fixed beta=0.25; train-only c0 recalibration.','', '| Model | Main100 success | Supplemental500 success | Filtered409 success | map8 success |','|---|---:|---:|---:|---:|',f"| UCF no-SFT | {results['main100']['success_rate_pct']:.2f} | {results['all500']['success_rate_pct']:.2f} | {results['filtered409']['success_rate_pct']:.2f} | {results['map8']['success_rate_pct']:.2f} |"]
    for name,row in plan['historical'].items():lines.append(f"| Historical {name} | {row['main100']} | {row['all500']} | — | {row['map8']} |")
    lines+=['','Paper success values supplied by the user: PaTR 75.8, GRPO 66.5, Random 56.3. They are separate reference numbers, not matched evaluations.','',*plan['limitations'],'','Detailed success/pass@4, smoke diagnostics, token costs and definitions: report.json and training_curves.json.']
    (Q/'REPORT.md').write_text('\n'.join(lines)+'\n')
    evidence=[FORMAL/'final_test.jsonl',Q/'map8/result.jsonl',*[FORMAL/f'supplemental500/batch{i}.jsonl' for i in range(1,6)]]
    atomic(Q/'verification.json',dict(verified=True,results=results,raw_sha256={str(p):sha(p) for p in evidence},report_sha256=sha(Q/'report.json'),all_400_steps=True,all_17_validations=True))
    print(json.dumps(results))

if __name__=='__main__':main()
