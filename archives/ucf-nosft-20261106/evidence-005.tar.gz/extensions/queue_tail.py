"""No-SFT successor; isolated system-disk outputs, frozen training sources."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'code'
PREDECESSOR = Path('/data/patr-storage/golden-ucf-20261103/code')
Q = HERE.parent / 'queue'
LIVE = ROOT / 'runs/formal/ucf/code'
FORMAL = LIVE / 'runs/formal/patr_seed42'
PY = '/home/vipuser/patr-reproduction/.venv/bin/python'
LOCK = Path('/home/vipuser/golden-controls-20261031/code/runs/control_queue/supervisor.lock')

def read(p):
    return json.loads(Path(p).read_text()) if Path(p).exists() else {}

def atomic(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n'); tmp.replace(p)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8*1024**2), b''): h.update(b)
    return h.hexdigest()

def diff(a, b):
    return {k: [a.get(k), b.get(k)] for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)}

def prerequisites(root=PREDECESSOR):
    q = root / 'runs/multiseed_queue'
    if read(q/'status.json').get('status') != 'complete_ucf_seeds42_43_and_reports_seed44_cancelled': return False
    report = read(q/'report.json')
    if not report.get('complete_requested_seeds') or not report.get('paired_seed43_vs_random43'): return False
    if not report.get('seed_mean_std') or report.get('available_seeds') != [42,43]: return False
    if report.get('cancelled_seeds') != [44] or not report.get('seed43_vs_seed42'): return False
    if not report['paired_seed43_vs_random43'].get('all500'): return False
    for name in ['training_curves.png','training_curves.svg',*[f'curves_seed{s}.json' for s in [42,43]]]:
        if not (q/name).is_file() or not (q/name).stat().st_size: return False
    for seed in [42,43]:
        run = root/f'runs/ucf_seed_replicates/seed{seed}/code/runs/formal/patr_seed{seed}'
        if read(run/'status.json').get('status') != 'complete': return False
        if read(run/'status.json').get('step') != 400: return False
        for name in ['final_test.json','final_test.jsonl',*[f'supplemental500/batch{i}.{ext}' for i in range(1,6) for ext in ['json','jsonl']]]:
            if not (run/name).is_file() or not (run/name).stat().st_size: return False
    return (root/'runs/phase2_queue/status.json').is_file() and read(root/'runs/phase2_queue/status.json').get('status') == 'complete_all_arms_and_seed43_report'

def status(s, **kw):
    atomic(Q/'status.json', dict(status=s, pid=os.getpid(), updated=time.time(), **kw))

def gpu():
    return subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()

def verify(plan, weights=False):
    for name, h in plan['source_sha256'].items(): assert sha(ROOT/name) == h, name
    for name, h in plan['extension_sha256'].items(): assert sha(HERE/name) == h, name
    for name, h in plan['fixed_files_sha256'].items(): assert sha(name) == h, name
    for name in ['runtime_override.json','deadline.json']: assert not (ROOT/'artifacts'/name).exists()
    assert read(ROOT/'configs/base.json') == plan['base_nosft']
    if weights:
        for name, h in plan['model_sha256'].items(): assert sha(Path(plan['model'])/name) == h, name

def preserve(p, label):
    if p.exists():
        dst = Q/'recovery'/f'{label}_{time.time_ns()}'
        dst.parent.mkdir(parents=True, exist_ok=True); p.rename(dst)
        atomic(dst.parent/(dst.name+'.receipt.json'), dict(original=str(p), preserved=str(dst), time=time.time()))

def run(stage, args, lease, cwd=ROOT):
    assert not gpu(), 'Another GPU process exists; no task launched'
    env = dict(os.environ, NEXT_GPU_LEASE_FD=str(lease.fileno()), CUDA_VISIBLE_DEVICES='0', PYTHONUNBUFFERED='1')
    with (Q/(stage+'.log')).open('a') as log:
        proc = subprocess.Popen([PY,'-u',*map(str,args)], cwd=cwd, env=env, pass_fds=(lease.fileno(),), stdout=log, stderr=subprocess.STDOUT)
        status('running', stage=stage, child_pid=proc.pid)
        result = proc.wait()
    assert result == 0, f'{stage} exited {result}; evidence retained'
    for _ in range(60):
        if not gpu(): return
        time.sleep(2)
    raise RuntimeError('GPU process remains after child exit; no successor launched')

def finalize():
    """Called only after the monitor has pushed and verified the exact evidence manifest."""
    receipt = read(Q/'publication_receipt.json'); manifest = Q/'publish/publication_manifest.json'
    assert receipt.get('remote_verified') is True and receipt.get('commit')
    assert receipt['publication_manifest_sha256'] == sha(manifest)
    assert read(Q/'report.json')['verified_complete']
    deletion = read(Q/'publish/deletion_manifest.json')
    assert deletion['allowed_scope'] == str(FORMAL/'checkpoint.pt')
    final_hashes = deletion['retained_final_model_sha256']
    for n,h in final_hashes.items(): assert sha(FORMAL/'final_model'/n) == h
    cp = FORMAL/'checkpoint.pt'
    if cp.exists():
        assert sha(cp) == deletion['checkpoint']['sha256']
        cp.unlink()
    atomic(Q/'cleanup_receipt.json', dict(time=time.time(), deleted=str(cp), checkpoint_sha256=deletion['checkpoint']['sha256'], retained_final_model_sha256=final_hashes, publication_commit=receipt['commit']))
    status('complete_nosft_training_evaluations_reports_published_checkpoint_removed', report=str(Q/'report.json'))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');ap.add_argument('--finalize',action='store_true');args=ap.parse_args()
    plan=read(HERE/'protocol.json');Q.mkdir(parents=True, exist_ok=True)
    if args.check:
        verify(plan, weights=True);print(json.dumps(dict(verified=True, prerequisites_ready=prerequisites())));return
    with (Q/'scheduler.lock').open('a+') as single:
        fcntl.flock(single,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if args.finalize: finalize();return
        if read(Q/'status.json').get('status','').startswith('complete_nosft_'): return
        while not prerequisites():
            status('waiting_ucf_seed43_all_tests_and_reports_seed44_cancelled');time.sleep(30)
        # Waiting never reserves the shared GPU lock.
        with LOCK.open('a+') as lease:
            while True:
                try: fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError: status('waiting_shared_gpu_lock');time.sleep(20);continue
                if not gpu(): break
                fcntl.flock(lease,fcntl.LOCK_UN);time.sleep(20)
            assert prerequisites();verify(plan, weights=True)
            assert shutil.disk_usage(ROOT).free >= 24*1024**3
            hw=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],text=True)
            atomic(Q/'hardware.json',dict(actual=hw,expected='NVIDIA A100-SXM4-40GB',time=time.time()))
            assert 'A100-SXM4-40GB' in hw
            atomic(Q/'predecessor_gate_receipt.json',dict(time=time.time(),status=read(PREDECESSOR/'runs/multiseed_queue/status.json'),report_sha256=sha(PREDECESSOR/'runs/multiseed_queue/report.json')))
            if not read(ROOT/'artifacts/calibration.json').get('nosft_train_only_complete'):
                run('calibration',[HERE/'calibrate_smoke.py','--stage','calibration'],lease)
            cal=read(ROOT/'artifacts/calibration.json');c0=cal['c0']
            expected=dict(plan['actual_seed42'],model=plan['model'],ucf_c0=c0,ucf_log_dir=str(LIVE/'ucf_logs'))
            delta=diff(plan['actual_seed42'],expected)
            assert set(delta) <= {'model','ucf_c0','ucf_log_dir'}
            atomic(Q/'config_final.json',expected);atomic(Q/'config_diff.json',dict(differences=delta,operational_only=['ucf_log_dir'],scientific=['model','ucf_c0']))
            if not read(ROOT/'artifacts/gpu_acceptance.json').get('nosft_smoke_passed'):
                run('smoke',[HERE/'calibrate_smoke.py','--stage','smoke'],lease)
            if read(FORMAL/'status.json').get('status') != 'complete':
                resume=(FORMAL/'checkpoint.pt').exists()
                if LIVE.exists() and not resume: preserve(LIVE,'formal_before_checkpoint')
                verify(plan)
                run('formal',['run_ucf.py','--variant','ucf','--beta','0.25','--c0',str(c0)]+(['--resume'] if resume else []),lease)
            assert read(FORMAL/'status.json').get('status')=='complete'
            assert read(LIVE/'config.json')==expected
            if not read(Q/'map8/identity.json').get('complete'):
                preserve(Q/'map8','map8_incomplete')
                run('map8',[HERE/'evaluate_map8.py'],lease)
        # CPU report/package never hold the shared GPU lock.
        verify(plan)
        status('generating_report')
        subprocess.run([PY,str(HERE/'report.py')],check=True,cwd=ROOT,env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
        subprocess.run([PY,str(HERE/'package.py')],check=True,cwd=ROOT)
        status('awaiting_github_publication_then_checkpoint_cleanup',report=str(Q/'report.json'))

if __name__=='__main__':
    try: main()
    except BlockingIOError: raise SystemExit('Existing no-SFT scheduler owns its lock')
    except Exception as exc:
        status('error_evidence_retained',error=repr(exc));raise
