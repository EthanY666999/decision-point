# UCF without SFT — seed42

Hardware: A100-SXM4-40GB. 400 steps, fixed beta=0.25; train-only c0 recalibration.

| Model | Main100 success | Supplemental500 success | Filtered409 success | map8 success |
|---|---:|---:|---:|---:|
| UCF no-SFT | 56.00 | 57.25 | 50.18 | 61.75 |
| Historical PaTR | 64.5 | 73.0 | — | 68.75 |
| Historical GRPO | 61.0 | 63.6 | — | 65.25 |
| Historical Random | 64.75 | 67.10000000000001 | — | 70.75 |

Paper success values supplied by the user: PaTR 75.8, GRPO 66.5, Random 56.3. They are separate reference numbers, not matched evaluations.

Historical October PaTR/GRPO/Random used earlier source versions and different hardware; descriptive references, not strict paired controls.
map8 aligns only the map-generation parameter with the cited upstream recipe, not an officially verified full paper reproduction.
Only one training seed for this no-SFT arm; no training-seed confidence interval.
c0 recalibration is predeclared and train-only. beta=.25 is fixed; inherited SFT Phase1 records document source provenance and do not claim a no-SFT Phase1 pass.
The scientific configuration changes are model and train-calibrated c0. ucf_log_dir changes only to isolate system-disk outputs; all other keys remain equal to UCF seed42.

Detailed success/pass@4, smoke diagnostics, token costs and definitions: report.json and training_curves.json.
